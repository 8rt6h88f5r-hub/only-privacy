use triton_vm::prelude::*;
pub const FIELD: u64 = 0xffff_ffff_0000_0001;
pub const HASH_DOMAIN: u64 = 0x4f4e4c5950524956;
pub fn hash_fields(values: &[u64]) -> [u64;5] {
    assert_eq!(values.len()%5,0);
    let digests: Vec<Digest> = values.chunks_exact(5).map(|s|Digest::new(std::array::from_fn(|i|BFieldElement::new(s[i])))).collect();
    if digests.len()==2 {return Tip5::hash_pair(digests[0],digests[1]).values().map(|x|x.value());}
    let mut acc=Digest::new([BFieldElement::new(digests.len() as u64),BFieldElement::new(HASH_DOMAIN),bfe!(0),bfe!(0),bfe!(0)]);
    for digest in digests {acc=Tip5::hash_pair(acc,digest);}
    acc.values().map(|x|x.value())
}
#[unsafe(no_mangle)]
pub unsafe extern "C" fn onlyprivacy_hash(input:*const u64, length:usize, output:*mut u64)->i32 {
    if input.is_null()||output.is_null()||length>1000||length%5!=0{return -1;}
    let values=unsafe{std::slice::from_raw_parts(input,length)};
    if values.iter().any(|&v|v>=FIELD){return -1;}
    let digest=hash_fields(values);unsafe{std::ptr::copy_nonoverlapping(digest.as_ptr(),output,5)};0
}
