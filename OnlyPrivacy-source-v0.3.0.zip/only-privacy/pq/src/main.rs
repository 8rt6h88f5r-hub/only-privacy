use std::io::{self, Read};
use triton_vm::prelude::*;
use base64::{Engine as _,engine::general_purpose::STANDARD};
use serde_json::{Value,json};
use onlyprivacy_pq::FIELD;
fn elements(value:&Value)->Result<Vec<BFieldElement>,String>{
    value.as_array().ok_or("Expected field array")?.iter().map(|x|{
        let s=x.as_str().ok_or("Expected field string")?;
        let v=s.parse::<u64>().map_err(|_|"Invalid field")?;
        if v>=FIELD||s!=v.to_string(){return Err("Noncanonical field".into());}
        Ok(BFieldElement::new(v))
    }).collect()
}
fn program()->Result<Program,String>{Program::from_code(include_str!("../transfer.tasm")).map_err(|e|format!("{e}"))}
fn main_op(req:Value)->Result<Value,String>{
    let program=program()?;let stark=Stark::default();
    match req["op"].as_str().ok_or("Missing operation")?{
        "info"=>Ok(json!({"system":"triton-stark-v1","version":9,"programDigest":program.hash().values().map(|x|x.value().to_string()),"securityParameter":stark.security_level,"trustedSetup":false})),
        "execute"|"prove"=>{
            let public=elements(&req["publicInput"])?;if public.len()!=65{return Err("Wrong public input length".into());}
            let input=PublicInput::from(public);
            let secret=elements(&req["secretInput"])?;if secret.len()!=432{return Err("Wrong private input length".into());}
            let (aet,output)=VM::trace_execution(program.clone(),input.clone(),NonDeterminism::from(secret)).map_err(|_|"Private witness rejected")?;
            if !output.is_empty(){return Err("Unexpected public output".into());}
            if req["op"]=="execute"{return Ok(json!({"valid":true}));}
            let claim=Claim::about_program(&program).with_input(input);
            let proof=stark.prove(&claim,&aet).map_err(|_|"Proof generation failed")?;
            if !triton_vm::verify(stark,&claim,&proof){return Err("Generated proof did not verify".into());}
            let bytes:Vec<u8>=proof.0.iter().flat_map(|v|v.value().to_le_bytes()).collect();
            Ok(json!({"system":"triton-stark-v1","bytes":STANDARD.encode(bytes),"paddedHeight":proof.padded_height().map_err(|_|"Invalid trace height")?}))
        },
        "verify"=>{
            let bytes=STANDARD.decode(req["proof"]["bytes"].as_str().ok_or("Missing proof")?).map_err(|_|"Invalid proof encoding")?;
            if bytes.len()>4*1024*1024||bytes.len()%8!=0{return Ok(json!(false));}
            let values=bytes.chunks_exact(8).map(|s|u64::from_le_bytes(s.try_into().unwrap())).collect::<Vec<_>>();
            if values.iter().any(|&v|v>=FIELD){return Ok(json!(false));}
            let proof=Proof(values.into_iter().map(BFieldElement::new).collect());
            if proof.padded_height().map_err(|_|"Malformed proof height")? != 65536{return Ok(json!(false));}
            let public=elements(&req["publicInput"])?;if public.len()!=65{return Ok(json!(false));}
            let claim=Claim::about_program(&program).with_input(PublicInput::from(public));
            Ok(json!(triton_vm::verify(stark,&claim,&proof)))
        },
        _=>Err("Unknown operation".into())
    }
}
fn main(){
    std::panic::set_hook(Box::new(|_|{}));
    let mut raw=String::new();
    if io::stdin().take(8*1024*1024+1).read_to_string(&mut raw).is_err()||raw.len()>8*1024*1024{std::process::exit(1);}
    let result=std::panic::catch_unwind(||serde_json::from_str(&raw).map_err(|_|"Invalid request".to_string()).and_then(main_op));
    match result {Ok(Ok(value))=>println!("{value}"),_=>{eprintln!("Proof operation rejected");std::process::exit(1);}}
}
