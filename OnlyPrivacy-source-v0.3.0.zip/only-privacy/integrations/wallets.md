# External wallet integration status

**No production MetaMask or Trust Wallet integration is included. Do not transfer OnlyPrivacy notes to an Ethereum address, import a different token under the same name, or represent a manually entered balance as custody.** The native Mac wallet is the functioning interface in this release. The actual owner allocation remains in its existing encrypted wallet.

## Common protocol boundary

The chain is not EVM and does not expose Ethereum JSON-RPC or `wallet_addEthereumChain` compatibility. A new wallet must implement the fixed STARK ownership/spending model, Tip5 Merkle commitments, domain-bound nullifiers, authenticated ML-KEM note recovery, pending input reservation, private-key persistence before publication, chain replay and reorganization handling. It must keep secrets and proving local. A public balance service would reveal wallet linkage or require viewing keys; it is not a substitute for private scanning.

`src/addresses.mjs` defines the versioned receive address codec and strict public-key/network validation. An invoice contains `protocol`, `domain`, `suite`, `owner` and the DER/SPKI ML-KEM public key. Addresses use `onlyprivacy:v1:` followed by canonical base64url of:

| Bytes | Meaning |
| --- | --- |
| 1 | version 1 |
| 1 | registered suite, currently 2 / ML-KEM-1024 |
| 40 | domain, five canonical little-endian 64-bit limbs |
| 40 | one-time owner digest, same limb encoding |
| 2 | DER public-key length, unsigned big endian |
| variable | DER/SPKI public key, algorithm must match suite |
| 8 | first eight SHA3-256 bytes of `OnlyPrivacy receive address v1\0` followed by all preceding bytes |

The checksum detects accidental alteration, not recipient identity or authenticity. The generation secret and KEM private key are never encoded. Every receive action generates fresh secrets/keys. Reject addresses for another domain or an unsupported suite. Tests include round trips, fresh-key uniqueness, tampering, wrong domains, noncanonical forms and wrong algorithms. Compact addresses fit the native wallet's QR representation; QR software must support the full string without truncation.

## MetaMask

The [official Snaps framework](https://docs.metamask.io/snaps/) supports non-EVM integrations. The custom program, KEM and private scanning must first be ported into supported Snap/Wasm execution, or connected through a reviewed hardware/companion wallet architecture. Keyring account/asset handling, user transaction approval, recovery, origin permissions and the non-EVM network namespace require end-to-end tests in an actual supported extension. This release does not provide those components and cannot move its 100-coin owner allocation into standard MetaMask yet.

The [official Flask guidance](https://docs.metamask.io/snaps/get-started/install-flask/) describes local custom Snap testing as development use and warns against importing funded accounts into Flask. Stable MetaMask accepts allowlisted audited Snaps. Do not promote a development fixture or a read-only snapshot as a finished supported wallet. No MetaMask recovery phrase was read or imported for this release.

## Trust Wallet

[New Blockchain Support](https://developer.trustwallet.com/developer/wallet-core/newblockchain) requires new address/signing functionality, core definitions, C/mobile bindings and tests, and states that prior Business Development approval is needed for upstream acceptance. Wallet Core support is a prerequisite and does not automatically make a coin available in the Trust Wallet application. The provider's published integration criteria also require a stable operating network and supporting infrastructure. This external decision cannot be completed by adding an RPC URL to this independent chain.

No integration request, email or external pull request has been sent to either provider. Preparing these requirements and code interfaces does not imply their approval or a support commitment.
