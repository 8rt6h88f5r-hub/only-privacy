import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');process.chdir(root);
for(const args of [['build','--locked','--release','--manifest-path','pq/Cargo.toml']]){
 const env={...process.env,RUSTFLAGS:(process.env.RUSTFLAGS??'')+' --remap-path-prefix='+root+'=.',CARGO_PROFILE_RELEASE_STRIP:'symbols'};
 const result=spawnSync('cargo',args,{stdio:'inherit',env});if(result.status!==0)process.exit(result.status??1);
}
await fs.mkdir('native',{recursive:true});
const exe=process.platform==='win32'?'onlyprivacy-pq.exe':'onlyprivacy-pq';
const lib=process.platform==='darwin'?'libonlyprivacy_pq.dylib':process.platform==='win32'?'onlyprivacy_pq.dll':'libonlyprivacy_pq.so';
for(const name of [exe,lib]){await fs.copyFile(path.join('pq/target/release',name),path.join('native',name+'.new'));if(process.platform==='darwin'&&name===lib){const changed=spawnSync('install_name_tool',['-id','@rpath/'+lib,path.join('native',name+'.new')],{stdio:'inherit'});if(changed.status!==0)throw Error('Library identity sanitization failed');const signed=spawnSync('codesign',['--force','--sign','-',path.join('native',name+'.new')],{stdio:'inherit'});if(signed.status!==0)throw Error('Local library integrity signing failed');}await fs.rename(path.join('native',name+'.new'),path.join('native',name));}
const result=spawnSync(path.join(root,'native',exe),[],{input:JSON.stringify({op:'info'}),encoding:'utf8'});if(result.status!==0)throw Error('Built proof engine rejected its fixed program');
const info=JSON.parse(result.stdout),hashes={};for(const file of ['pq/transfer.tasm','pq/witness-layout.json','pq/Cargo.lock'])hashes[file]=createHash('sha256').update(await fs.readFile(file)).digest('hex');
await fs.writeFile('pq/proof-program.json',JSON.stringify({upstream:'https://github.com/TritonVM/triton-vm',revision:'2f3d61789b45bd90d3aaf7a6b191f5b46894c5bd',system:info.system,securityParameter:info.securityParameter,programDigest:info.programDigest,trustedSetup:false,hashes},null,2)+'\n');
console.log('Fixed transparent STARK prover and verifier built; no secret ceremony.');
