import fs from 'node:fs/promises';
import path from 'node:path';
import {randomBytes,randomUUID} from 'node:crypto';
import {Wallet} from '../src/wallet.mjs';
import {Chain} from '../src/chain.mjs';
import {PROJECT} from '../src/proofs.mjs';
import {checkArtifacts,checkPrivateFile} from '../src/security.mjs';
import {readJSON,writeJSON,exclusiveMany} from '../src/storage.mjs';
import {storeOwnerSecret,readOwnerSecret,removeOwnerSecret} from '../src/keychain.mjs';
import {buildTransaction} from '../src/transactions.mjs';
import {transactionPacket} from '../src/node.mjs';
import {formatAmount,parseAmount,FEE} from '../src/emission.mjs';
import {submitTransaction,onionEndpoint} from '../src/transport.mjs';
import {downloadCandidate} from '../src/synchronization.mjs';
import {encodeAddress,decodeAddress} from '../src/addresses.mjs';

// Native application transport only: one bounded request on stdin, no HTTP/RPC listener.
process.chdir(PROJECT);
const allowed=new Set(['snapshot','create','invoice','prepare','renew','submit','sync']);
const checkpoint=await readJSON(path.join(PROJECT,'network/checkpoint.json'));
let chain;
function required(value,label){if(typeof value!=='string'||!value.trim()||value.length>8192)throw Error(label+' is required');return value;}
async function metadata(file){
 file=path.resolve(required(file,'Wallet metadata'));if(!await checkPrivateFile(file))throw Error('Wallet metadata must be private');
 const data=await readJSON(file,16384);
 if(data.version!==1||data.coin!=='OnlyPrivacy'||data.wallet!=='wallet.enc.json'||data.chain!=='chain.json'||data.genesis!==checkpoint.genesis||!/^org\.onlyprivacy\.owner\.[a-f0-9]{32}$/.test(data.keychainService))throw Error('Incompatible wallet metadata');
 const directory=path.dirname(file);return {file,data,directory,wallet:path.join(directory,data.wallet),chain:path.join(directory,data.chain)};
}
function snapshot(wallet,record){
 const b=wallet.scan(chain);
 return {total:formatAmount(b.total),available:formatAmount(b.available),locked:formatAmount(b.locked),reserved:formatAmount(b.reserved),
  height:chain.height,suite:chain.activeSuite(),genesis:chain.blocks[0].id,metadata:record.file,
  pending:wallet.data.pending.length,initialTotal:'10000',reserveRemaining:formatAmount(chain.reserveRemaining),stage:'Public test network · independent audit pending'};
}
async function main(request){
 if(!request||!allowed.has(request.operation))throw Error('Unsupported wallet operation');
 if(!(await checkArtifacts()).ok)throw Error('Cryptographic program integrity check failed');
 if(request.operation==='create'){
  const directory=path.resolve(required(request.directory,'New wallet directory'));
  if(directory===PROJECT||directory.startsWith(PROJECT+path.sep))throw Error('Keep private wallets outside the distributed program');
  if(typeof request.password!=='string'||request.password.length<12||request.password.length>1024)throw Error('Use a password of 12–1024 characters');
  await fs.mkdir(directory,{mode:0o700});
  const service='org.onlyprivacy.owner.'+randomBytes(16).toString('hex');let stored=false,published=false;
  try{
   const file=path.join(directory,'wallet.enc.json');const wallet=await Wallet.create(file,request.password);
   chain=await Chain.load('network/genesis.json');if(chain.blocks[0].id!==checkpoint.genesis)throw Error('Wrong public genesis');await chain.save(path.join(directory,'chain.json'));
   storeOwnerSecret(service,request.password);stored=true;
   const record={version:1,coin:'OnlyPrivacy',keychainService:service,wallet:'wallet.enc.json',chain:'chain.json',genesis:checkpoint.genesis};
   const meta=path.join(directory,'owner.json');await writeJSON(meta,record,0o600,{replace:false});published=true;
   return {ok:true,snapshot:snapshot(wallet,await metadata(meta)),notice:'New wallet joined the existing chain with zero coins; no new genesis or premine.'};
  }finally{if(stored&&!published)removeOwnerSecret(service);request.password='';}
 }
 const record=await metadata(request.metadata);
 return exclusiveMany([record.wallet,record.chain],async()=>{
  chain=await Chain.load(record.chain);
  if(chain.blocks[0].id!==checkpoint.genesis)throw Error('Wrong network checkpoint');
  if(!await checkPrivateFile(record.wallet))throw Error('Wallet file must have private permissions');
  // Only this selected OnlyPrivacy wallet's Keychain entry can be opened.
  const password=readOwnerSecret(record.data.keychainService),wallet=await Wallet.load(record.wallet,password);
  if(request.operation==='snapshot')return {ok:true,snapshot:snapshot(wallet,record)};
  if(request.operation==='invoice'){
   const invoice=wallet.invoice(chain.config.domain,chain.activeSuite());await wallet.save(record.wallet,password);
   const file=path.join(record.directory,'receive-'+randomUUID()+'.json');await writeJSON(file,invoice,0o600,{replace:false});
   return {ok:true,snapshot:snapshot(wallet,record),invoice:encodeAddress(invoice),invoiceFile:file};
  }
  if(request.operation==='sync'){
   const endpoint=required(request.endpoint,'Onion endpoint');onionEndpoint(endpoint);
   const candidate=await downloadCandidate(endpoint,chain,{proxyPort:19050,candidateFile:record.chain+'.sync-candidate.json'});
   if(candidate){try{await candidate.save(record.chain);chain.replace(candidate);}catch(error){candidate.close();throw error;}}
   wallet.scan(chain);await wallet.save(record.wallet,password);return {ok:true,snapshot:snapshot(wallet,record)};
  }
  if(request.operation==='submit'){
   const endpoint=required(request.endpoint,'Onion endpoint');onionEndpoint(endpoint);
   const packet=await readJSON(path.resolve(required(request.packetFile,'Public transaction file')),6*1024*1024+1024);
   if(packet.genesis!==checkpoint.genesis)throw Error('Transaction belongs to another network');
   const submitted=await submitTransaction(endpoint,packet,{proxyPort:19050});return {ok:true,snapshot:snapshot(wallet,record),submitted};
  }
  let tx;
  if(request.operation==='prepare'){
   const recipient=request.address?decodeAddress(request.address,chain.config.domain):await readJSON(path.resolve(required(request.recipientFile,'One-time recipient file')),16384);
   tx=await buildTransaction(chain,wallet,{recipient,amount:parseAmount(required(request.amount,'Amount'))});
  }else{
   wallet.scan(chain);
   const inputs=wallet.data.notes.filter(n=>!n.spent&&!n.reserved&&Number(n.lock)<=chain.blocks.length).sort((a,b)=>BigInt(a.value)>BigInt(b.value)?-1:1).slice(0,2);
   const amount=inputs.reduce((s,n)=>s+BigInt(n.value),0n)-FEE;if(amount<=0n)throw Error('No unlocked coins available to renew');
   tx=await buildTransaction(chain,wallet,{recipient:wallet.invoice(chain.config.domain,chain.activeSuite()),amount,inputs});
  }
  const file=path.join(record.directory,request.operation+'-'+randomUUID()+'.json');wallet.reserve(tx,chain);await wallet.save(record.wallet,password);
  await writeJSON(file,transactionPacket(chain,tx),0o600,{replace:false});return {ok:true,snapshot:snapshot(wallet,record),packetFile:file};
 });
}
try{
 const chunks=[];let size=0;for await(const chunk of process.stdin){size+=chunk.length;if(size>256*1024)throw Error('Wallet request too large');chunks.push(chunk);}
 const input=Buffer.concat(chunks);let request;try{request=JSON.parse(input.toString('utf8'));}finally{input.fill(0);for(const c of chunks)c.fill(0);}
 const result=await main(request);console.log(JSON.stringify(result));
}catch(error){console.log(JSON.stringify({ok:false,error:error.message}));process.exitCode=1;}finally{chain?.close();}
