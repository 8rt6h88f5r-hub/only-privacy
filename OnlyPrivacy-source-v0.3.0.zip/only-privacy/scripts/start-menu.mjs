import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createInterface } from 'node:readline/promises';
import { spawn } from 'node:child_process';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
process.chdir(root);
const r=createInterface({input:process.stdin,output:process.stdout});
console.log('\n온리프라이버시 / OnlyPrivacy\n1. 내 100개 보관 지갑 열기\n2. 별도 채굴 참여 지갑과 CPU 채굴\n3. 이 컴퓨터에서 Tor 노드 실행 (Ctrl+C로 종료)\n4. 암호화 프로그램 무결성 확인\n0. 종료\n프로그램 이용료는 없습니다. 채굴·노드 실행에는 전기와 인터넷이 사용됩니다.');
const choice=(await r.question('선택: ')).trim();r.close();
const args={'1':['scripts/owner-menu.mjs'],'2':['scripts/miner-menu.mjs'],'3':['scripts/start-node.mjs'],'4':['src/cli.mjs','doctor']}[choice];
if(args){const child=spawn(process.execPath,args,{cwd:root,stdio:'inherit'});child.once('error',error=>{console.error(error.message);process.exitCode=1;});child.once('exit',code=>{process.exitCode=code??1;});}
