import fs from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
import path from 'node:path';
import { PROJECT } from '../src/proofs.mjs';
process.chdir(PROJECT);
for(const args of [['-S','vendor/randomx','-B','build/randomx','-DBUILD_SHARED_LIBS=ON','-DCMAKE_BUILD_TYPE=Release','-DCMAKE_POLICY_VERSION_MINIMUM=3.5','-DCMAKE_INSTALL_NAME_DIR=@rpath','-DCMAKE_BUILD_WITH_INSTALL_NAME_DIR=ON','-DCMAKE_CXX_FLAGS=-ffile-prefix-map='+PROJECT+'=.'],['--build','build/randomx','--target','randomx','--config','Release','--parallel','2']]) {
  const result=spawnSync('cmake',args,{stdio:'inherit'});if(result.status!==0)process.exit(result.status??1);
}
const name=process.platform==='darwin'?'librandomx.dylib':process.platform==='win32'?'randomx.dll':'librandomx.so';
const candidates=[path.join('build/randomx',name),path.join('build/randomx/Release',name)];
let source;for(const candidate of candidates){if(await fs.access(candidate).then(()=>true,()=>false)){source=candidate;break;}}
if(!source)throw Error('Native RandomX output not found');await fs.mkdir('native',{recursive:true});await fs.copyFile(source,path.join('native',name+'.new'));await fs.rename(path.join('native',name+'.new'),path.join('native',name));
console.log('RandomX native library built for '+process.platform+'/'+process.arch);
