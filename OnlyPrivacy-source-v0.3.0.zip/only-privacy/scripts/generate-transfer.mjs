import fs from 'node:fs/promises';
// Generates the complete, fixed straight-line transfer verifier. No secret-dependent branches.
const DEPTH=32,DOMAIN=BigInt('0x4f4e4c5950524956').toString(),lines=[];let next=100;
const emit=(...s)=>lines.push(...s),alloc=()=>{const a=next;next+=5;return a;};
const load=a=>emit(`push ${a} read_mem 1 pop 1`);
const store=a=>emit(`push ${a} write_mem 1 pop 1`);
const put=(a,n)=>{emit(`push ${n}`);store(a);};
const scalar=(a,n=0)=>{for(let j=0;j<5;j++)put(a+j,j===0?n:0);};
const read=(a,secret=false)=>{for(let j=0;j<5;j++){emit(secret?'divine 1':'read_io 1');store(a+j);}};
const privateNumber=a=>{emit('divine 1');store(a);for(let j=1;j<5;j++)put(a+j,0);};
const pair=(a,b,out)=>{
  for(let j=4;j>=0;j--)load(b+j);for(let j=4;j>=0;j--)load(a+j);
  emit('hash');for(let j=0;j<5;j++)store(out+j);
};
const hash=(args,out)=>{
  if(args.length===2)return pair(args[0],args[1],out);
  const acc=alloc();scalar(acc,args.length);put(acc+1,DOMAIN);
  for(const a of args)pair(acc,a,acc);
  for(let j=0;j<5;j++){load(acc+j);store(out+j);}
};
const range32=a=>{load(a);emit('push 0 lt pop 1');};
const number63=a=>{
  for(let j=1;j<5;j++){load(a+j);emit('push 0 eq assert');}
  load(a);emit('split');const lo=alloc(),hi=alloc();store(lo);store(hi);
  load(hi);emit('push 2147483648 swap 1 lt assert');return {lo,hi};
};
const number32=a=>{for(let j=1;j<5;j++){load(a+j);emit('push 0 eq assert');}range32(a);};
const assertEqual=(a,b,condition=null)=>{
  for(let j=0;j<5;j++){
    load(a+j);load(b+j);emit('push -1 mul add');
    if(condition!==null){load(condition);emit('mul');}emit('push 0 eq assert');
  }
};
const publicNames=['n0','n1','c0','c1','binding','domain','root','mint','fee','extHash','height','stake','stakeLock'];
const pub=Object.fromEntries(publicNames.map(n=>[n,alloc()]));
for(const name of publicNames)read(pub[name]);
const privateLayout=[];
function priv(name,numeric=false){const address=alloc();privateLayout.push({name,numeric});if(numeric)privateNumber(address);else read(address,true);return address;}
const ins=[];
for(let i=0;i<2;i++){
  const n={secret:priv(`inSecret.${i}`),rho:priv(`inRho.${i}`),value:priv(`inValue.${i}`,true),lock:priv(`inLock.${i}`,true),siblings:[],bits:[]};
  for(let d=0;d<DEPTH;d++)n.siblings.push(priv(`siblings.${i}.${d}`));
  for(let d=0;d<DEPTH;d++)n.bits.push(priv(`pathBits.${i}.${d}`,true));ins.push(n);
}
const outs=[];for(let i=0;i<2;i++)outs.push({owner:priv(`outOwner.${i}`),rho:priv(`outRho.${i}`),value:priv(`outValue.${i}`,true),lock:priv(`outLock.${i}`,true)});
const tags={};for(const n of [101,102,103,104]){tags[n]=alloc();scalar(tags[n],n);}
const zero=alloc();scalar(zero);
const amountParts={};for(const name of ['mint','fee','stake'])amountParts[name]=number63(pub[name]);
for(const name of ['height','stakeLock'])number32(pub[name]);
const inputParts=[],outputParts=[];
for(let i=0;i<2;i++){
  const n=ins[i],o=outs[i];inputParts.push(number63(n.value));outputParts.push(number63(o.value));number32(n.lock);number32(o.lock);
  const nonempty=alloc();load(n.value);emit('push 0 eq push -1 mul push 1 add');store(nonempty);
  // lock <= height, enforced only for a non-empty input.
  load(n.lock);load(pub.height);emit('lt');load(nonempty);emit('mul push 0 eq assert');
  const owner=alloc(),cm=alloc(),nf=alloc(),node=alloc();
  hash([tags[101],n.secret,pub.domain],owner);
  hash([tags[102],pub.domain,owner,n.value,n.rho,n.lock],cm);
  for(let j=0;j<5;j++){load(cm+j);store(node+j);}
  for(let d=0;d<DEPTH;d++){
    const bit=n.bits[d],left=alloc(),right=alloc();
    load(bit);load(bit);emit('push -1 add mul push 0 eq assert');
    for(let j=0;j<5;j++){
      load(n.siblings[d]+j);load(node+j);emit('push -1 mul add');load(bit);emit('mul');load(node+j);emit('add');store(left+j);
      load(node+j);load(n.siblings[d]+j);emit('push -1 mul add');load(bit);emit('mul');load(n.siblings[d]+j);emit('add');store(right+j);
    }
    hash([left,right],node);
  }
  assertEqual(node,pub.root,nonempty);
  hash([tags[103],n.secret,n.rho,pub.domain],nf);
  for(let j=0;j<5;j++){load(nf+j);load(nonempty);emit('mul');store(nf+j);}
  assertEqual(nf,pub['n'+i]);
  const output=alloc();hash([tags[102],pub.domain,o.owner,o.value,o.rho,o.lock],output);assertEqual(output,pub['c'+i]);
}
// Exact integer conservation using independent 32-bit limbs, never field-wrap sums.
// Low limbs determine a carry/borrow; high limbs must satisfy the same carry.
const lowDifference=alloc();
load(inputParts[0].lo);load(inputParts[1].lo);emit('add');load(amountParts.mint.lo);emit('add');
load(outputParts[0].lo);emit('push -1 mul add');load(outputParts[1].lo);emit('push -1 mul add');load(amountParts.fee.lo);emit('push -1 mul add');store(lowDifference);
const highDifference=alloc();
load(inputParts[0].hi);load(inputParts[1].hi);emit('add');load(amountParts.mint.hi);emit('add');
load(outputParts[0].hi);emit('push -1 mul add');load(outputParts[1].hi);emit('push -1 mul add');load(amountParts.fee.hi);emit('push -1 mul add');store(highDifference);
// Each side has three nonnegative 63-bit values. Difference may only be -2..2 base-2^32 carries.
// Polynomial forces the signed carry to be one of -2, -1, 0, 1, 2.
load(highDifference);load(highDifference);emit('push -1 add mul');load(highDifference);emit('push 1 add mul');load(highDifference);emit('push -2 add mul');load(highDifference);emit('push 2 add mul push 0 eq assert');
load(highDifference);emit('push 4294967296 mul');load(lowDifference);emit('add push 0 eq assert');
const staking=alloc();load(pub.stake);emit('push 0 eq push -1 mul push 1 add');store(staking);
assertEqual(outs[0].value,pub.stake,staking);assertEqual(outs[0].lock,pub.stakeLock,staking);
const binding=alloc();hash([tags[104],outs[0].rho,pub.extHash,pub.root,pub.domain,pub.height],binding);assertEqual(binding,pub.binding);
emit('halt');
await fs.writeFile(new URL('../pq/transfer.tasm',import.meta.url),'// OnlyPrivacy fixed transfer program: 2 inputs, 2 outputs, depth32.\n'+lines.join('\n')+'\n');
await fs.writeFile(new URL('../pq/witness-layout.json',import.meta.url),JSON.stringify({depth:DEPTH,publicNames,privateLayout},null,2)+'\n');
console.log(JSON.stringify({instructions:lines.length,privateFields:privateLayout.reduce((n,p)=>n+(p.numeric?1:5),0),memoryWords:next}));
