import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawn } from 'node:child_process';
import { Chain } from '../src/chain.mjs';
import { exclusive } from '../src/storage.mjs';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');process.chdir(root);
const directory=path.resolve('data/public-node'),torDirectory=path.join(directory,'tor'),onionDirectory=path.join(directory,'onion');
await fs.mkdir(onionDirectory,{recursive:true,mode:0o700});
await exclusive(path.join(directory,'service'),async()=>{
 const file=path.join(directory,'chain.json');
 if(!await fs.access(file).then(()=>true,()=>false)){const chain=await Chain.load('network/genesis.json');try{await chain.save(file);}finally{chain.close();}}
 const config=['ClientOnly 1','SocksPort 127.0.0.1:19050 IsolateSOCKSAuth','DataDirectory '+JSON.stringify(torDirectory),'HiddenServiceDir '+JSON.stringify(onionDirectory),'HiddenServiceVersion 3','HiddenServicePort 80 127.0.0.1:18773','Log notice stdout'].join('\n')+'\n';
 const torrc=path.join(directory,'torrc');await fs.writeFile(torrc,config,{mode:0o600});
 const env=Object.fromEntries(['PATH','TMPDIR','SYSTEMROOT'].filter(k=>process.env[k]).map(k=>[k,process.env[k]]));
 const tor=spawn((process.env.ONLYPRIVACY_TOR_BIN??path.join(root,'runtime/tor/tor')),['-f',torrc],{env,stdio:['ignore','pipe','inherit']});
 const node=spawn(process.execPath,['src/cli.mjs','serve',file,'18773'],{env,stdio:['ignore','inherit','inherit']});
 let stopped=false;const stop=()=>{if(stopped)return;stopped=true;tor.kill('SIGTERM');node.kill('SIGTERM');};
 process.once('SIGINT',stop);process.once('SIGTERM',stop);
 const torExit=new Promise(resolve=>{tor.once('error',resolve);tor.once('exit',resolve);});
 const nodeExit=new Promise(resolve=>{node.once('error',resolve);node.once('exit',resolve);});
 tor.stdout.on('data',chunk=>{process.stdout.write(chunk);});
 let hostname='';
 for(let n=0;n<120&&!stopped;n++){
  try{hostname=(await fs.readFile(path.join(onionDirectory,'hostname'),'utf8')).trim();break;}catch{await new Promise(resolve=>setTimeout(resolve,500));}
 }
 if(hostname){await fs.writeFile(path.join(directory,'public-endpoint.json'),JSON.stringify({endpoint:'http://'+hostname+'/',localSocksPort:19050,chain:file})+'\n',{mode:0o600});console.log('온리프라이버시 공개 노드: http://'+hostname+'/ · 중지: Ctrl+C · 지갑 비밀키를 열지 않습니다.');}
 await Promise.race([torExit,nodeExit]);stop();await Promise.all([torExit,nodeExit]);
});
