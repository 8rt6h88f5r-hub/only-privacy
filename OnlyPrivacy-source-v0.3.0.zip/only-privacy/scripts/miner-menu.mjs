import net from 'node:net';
import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawn } from 'node:child_process';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');process.chdir(root);
const isProxyListening=()=>new Promise(resolve=>{const socket=net.connect({host:'127.0.0.1',port:19050});socket.once('connect',()=>{socket.destroy();resolve(true);});socket.once('error',()=>resolve(false));});
let tor;
try{
 if(!await isProxyListening()){
  const directory=path.resolve('data/miner-tor');await fs.mkdir(directory,{recursive:true,mode:0o700});
  const file=path.join(directory,'torrc');await fs.writeFile(file,'ClientOnly 1\nSocksPort 127.0.0.1:19050 IsolateSOCKSAuth\nDataDirectory '+JSON.stringify(directory)+'\nLog notice stdout\n',{mode:0o600});
  tor=spawn((process.env.ONLYPRIVACY_TOR_BIN??path.join(root,'runtime/tor/tor')),['-f',file],{stdio:['ignore','pipe','inherit']});
  console.log('Tor 연결을 준비하고 있습니다. 채굴은 메뉴에서 선택할 때만 실행합니다.');
  await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('Tor 연결 준비 시간이 초과되었습니다. 다시 실행하세요.')),180000);tor.once('error',reject);tor.once('exit',()=>reject(Error('Tor가 종료되었습니다.')));tor.stdout.on('data',chunk=>{const text=chunk.toString();if(text.includes('Bootstrapped'))process.stdout.write(text);if(text.includes('Bootstrapped 100%')){clearTimeout(timer);resolve();}});});
 }
 const child=spawn(process.execPath,['src/cli.mjs','menu'],{stdio:'inherit',env:{...process.env,ONLYPRIVACY_TOR_PROXY_PORT:'19050'}});
 const code=await new Promise((resolve,reject)=>{child.once('error',reject);child.once('exit',resolve);});process.exitCode=code??1;
}catch(error){console.error(error.message);process.exitCode=1;}finally{tor?.kill('SIGTERM');}
