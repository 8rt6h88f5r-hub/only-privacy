#!/usr/bin/env python3
"""Create a local, allowlisted source backup. Never upload or include custody."""
from pathlib import Path
import hashlib
import json
import re
import stat
import zipfile

ROOT = Path(__file__).resolve().parent.parent
DEST = ROOT.parent / 'OnlyPrivacy-source-v0.3.0.zip'
FILES = [
    '.gitignore', 'LICENSE', 'package.json', 'pnpm-lock.yaml',
    'rust-toolchain.toml', 'README.md', 'PROTOCOL.md', 'SECURITY.md', 'BUILD.md', 'PUBLIC_TESTNET.md',
    'network/genesis.json', 'network/checkpoint.json',
    'config/torrc.example', 'config/peers.example.json', 'config/peers.json',
    'pq/Cargo.toml', 'pq/Cargo.lock', 'pq/transfer.tasm',
    'pq/witness-layout.json', 'pq/proof-program.json',
    'reports/release-final.tap', 'reports/owner-allocation-public.json',
    'reports/검증결과.md', 'reports/release-status.json', 'reports/tor-provenance.json',
    'reports/public-release-tests.tap', 'reports/dependency-advisories.json', 'reports/public-node-probe.json',
]
TREES = {
    'src': {'.mjs'}, 'scripts': {'.mjs', '.py'},
    'tests': {'.mjs'}, 'pq/src': {'.rs'}, 'vendor/randomx': None,
    'wallet': {'.swift','.md'}, 'assets': {'.svg','.png'}, 'integrations': {'.md'},
}
FORBIDDEN_PARTS = {'node_modules', 'target', 'build', 'runtime', 'data',
                   '.git', '.build-deps', '__pycache__', '.DS_Store'}

def digest(data):
    return hashlib.sha256(data).hexdigest()

def private_markers():
    # Compare privately, never print values. The source backup works without this folder.
    owner = ROOT.parent / '온리프라이버시_내지갑_100개'
    markers = []
    metadata = owner / 'owner.json'
    if metadata.exists():
        markers.append(json.loads(metadata.read_text())['keychainService'].encode())
    # The explicitly published testnet hostname is public; service secret keys remain excluded.
    return [m for m in markers if m]

def select():
    selected = set(FILES)
    for folder, extensions in TREES.items():
        for p in (ROOT / folder).rglob('*'):
            rel = p.relative_to(ROOT)
            if set(rel.parts) & FORBIDDEN_PARTS:
                continue
            if p.is_symlink():
                raise ValueError('Source tree contains a symlink; inspect before packaging')
            if p.is_file() and (extensions is None or p.suffix in extensions):
                selected.add(rel.as_posix())
    blobs = {}
    markers = private_markers()
    for name in sorted(selected):
        p = ROOT / name
        if p.is_symlink() or not p.is_file() or not p.resolve().is_relative_to(ROOT):
            raise ValueError('Missing or nonlocal allowlisted source')
        if set(p.relative_to(ROOT).parts) & FORBIDDEN_PARTS:
            raise ValueError('Excluded source path')
        raw = p.read_bytes()
        if (any(marker in raw for marker in markers)
            or re.search(rb'/Users/[A-Za-z0-9_.-]+/', raw)
            or (b'-----BEGIN ' + b'PRIVATE KEY-----') in raw
            or (b'-----BEGIN ' + b'OPENSSH PRIVATE KEY-----') in raw):
            raise ValueError('Private data or a machine path found; no archive written')
        blobs[name] = raw
    return blobs

def info(name, executable=False):
    entry = zipfile.ZipInfo('only-privacy/' + name, date_time=(2026, 10, 18, 0, 0, 0))
    entry.create_system = 3
    entry.external_attr = (stat.S_IFREG | (0o755 if executable else 0o644)) << 16
    entry.compress_type = zipfile.ZIP_DEFLATED
    return entry

def main():
    blobs = select()
    manifest = {
        'format': 'onlyprivacy-source-manifest-v1', 'version': '0.3.0',
        'genesis': json.loads(blobs['network/checkpoint.json'])['genesis'],
        'privateCustodyIncluded': False, 'runtimeBinariesIncluded': False,
        'files': {name: digest(raw) for name, raw in blobs.items()},
    }
    manifest_raw = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode()
    temporary = DEST.with_suffix('.zip.new')
    try:
        with zipfile.ZipFile(temporary, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            for name, raw in blobs.items():
                archive.writestr(info(name, name.endswith('.py')), raw)
            archive.writestr(info('SOURCE-MANIFEST.json'), manifest_raw)
        with zipfile.ZipFile(temporary) as archive:
            if archive.testzip() is not None:
                raise ValueError('Archive verification failed')
            for name, expected in manifest['files'].items():
                if digest(archive.read('only-privacy/' + name)) != expected:
                    raise ValueError('Archive content mismatch')
        temporary.replace(DEST)
        checksum = digest(DEST.read_bytes())
        DEST.with_suffix('.zip.sha256').write_text(checksum + '  ' + DEST.name + '\n')
        (ROOT / 'reports/source-package.json').write_text(json.dumps({
            'archive': DEST.name, 'sha256': checksum, 'bytes': DEST.stat().st_size,
            'sourceFiles': len(blobs), 'manifestVerified': True,
            'privateCustodyIncluded': False, 'uploaded': False,
        }, indent=2) + '\n')
        print(json.dumps({'archive': DEST.name, 'sourceFiles': len(blobs),
                          'bytes': DEST.stat().st_size, 'verified': True,
                          'privateCustodyIncluded': False, 'uploaded': False}))
    finally:
        temporary.unlink(missing_ok=True)

if __name__ == '__main__':
    main()
