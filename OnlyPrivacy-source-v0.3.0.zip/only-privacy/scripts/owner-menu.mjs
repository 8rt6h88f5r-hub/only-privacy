import fs from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createInterface } from 'node:readline/promises';
import { spawn } from 'node:child_process';
import { randomUUID } from 'node:crypto';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const directory=path.resolve(root,'../온리프라이버시_내지갑_100개');
const wallet=path.join(directory,'wallet.enc.json'),chain=path.join(directory,'chain.json');
const metadata=path.join(directory,'owner.json');
process.chdir(root);
const cli=args=>new Promise((resolve,reject)=>{
  const env={...process.env,ONLYPRIVACY_OWNER_METADATA:metadata};
  delete env.IPC_WALLET_PASSWORD;delete env.ONLYP_WALLET_PASSWORD;delete env.ONLYPRIVACY_WALLET_PASSWORD;
  const child=spawn(process.execPath,['src/cli.mjs',...args],{cwd:root,env,stdio:'inherit'});
  child.once('error',reject);child.once('exit',code=>resolve(code===0));
});
const packetPath=kind=>path.join(directory,kind+'-'+randomUUID()+'.json');
const filePath=input=>path.resolve(input.trim().replace(/^['"]|['"]$/g,''));
let lastPacket='';
try{
  await fs.access(metadata);await fs.access(wallet);
  for(;;){
    const r=createInterface({input:process.stdin,output:process.stdout});
    let args;
    try{
      console.log('\n온리프라이버시 · 내 지갑\n1. 잔액 확인\n2. 새 일회용 받는 주소 파일 만들기\n3. 보낼 거래 파일 만들기\n4. 만든 거래를 Tor 노드에 제출\n5. 오래 보관한 코인 갱신 거래 만들기\n6. Tor 노드에서 최신 장부 받기\n7. 지갑 보관 안내\n0. 종료');
      const choice=(await r.question('선택: ')).trim();
      if(choice==='0')break;
      if(choice==='1')args=['balance',wallet,chain];
      else if(choice==='2')args=['invoice',wallet,chain,packetPath('receive-once')];
      else if(choice==='3'){
        const invoice=(await r.question('상대방에게 받은 일회용 주소 파일: ')).trim();
        const amount=(await r.question('보낼 ONLYP 수량 (수수료 0.000001 별도): ')).trim();
        if(!invoice||!amount)continue;
        lastPacket=packetPath('transaction');args=['prepare',filePath(invoice),amount,wallet,chain,lastPacket];
      }else if(choice==='4'){
        const file=(await r.question('제출할 거래 파일'+(lastPacket?' [방금 만든 파일]':'')+': ')).trim()||lastPacket;
        const endpoint=(await r.question('참여 노드의 http://…onion/ 주소: ')).trim();
        if(!file||!endpoint)continue;
        args=['submit',filePath(file),endpoint];
      }else if(choice==='5'){
        lastPacket=packetPath('renewal');args=['renew',wallet,chain,lastPacket];
      }else if(choice==='6'){
        const endpoint=(await r.question('동기화할 노드의 http://…onion/ 주소: ')).trim();
        if(!endpoint)continue;
        args=['sync',endpoint,chain];
      }else if(choice==='7'){
        console.log(await fs.readFile(path.join(directory,'사용법.txt'),'utf8'));continue;
      }else continue;
      if(choice==='4'||choice==='6')console.log('Tor가 필요합니다. 다른 창에서 노드공유.command를 실행하면 준비됩니다. 직접 인터넷 연결로 우회하지 않습니다.');
    }finally{r.close();}
    await cli(args);
  }
}catch(error){console.error(error.message);process.exitCode=1;}
