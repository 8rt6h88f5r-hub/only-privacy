import SwiftUI
import AppKit
import CoreImage.CIFilterBuiltins
import UniformTypeIdentifiers

struct WalletSnapshot: Decodable {
    let total, available, locked, reserved, genesis, metadata, reserveRemaining: String
    let height, suite, pending: Int
}
struct BridgeReply: Decodable {
    let ok: Bool
    let error: String?
    let snapshot: WalletSnapshot?
    let invoice, invoiceFile, packetFile: String?
}
enum Bridge {
    static var root: URL { Bundle.main.resourceURL!.appendingPathComponent("only-privacy") }
    static func invoke(_ input: Data) throws -> Data {
        let process = Process(), incoming = Pipe(), outgoing = Pipe(), diagnostic = Pipe()
        process.executableURL = root.appendingPathComponent("runtime/node/bin/node")
        process.arguments = [root.appendingPathComponent("scripts/wallet-bridge.mjs").path]
        process.currentDirectoryURL = root
        process.environment = ["PATH":"/usr/bin:/bin:/usr/sbin:/sbin", "TMPDIR":NSTemporaryDirectory()]
        process.standardInput = incoming; process.standardOutput = outgoing; process.standardError = diagnostic
        try process.run()
        incoming.fileHandleForWriting.write(input)
        try incoming.fileHandleForWriting.close()
        let output = outgoing.fileHandleForReading.readDataToEndOfFile()
        process.waitUntilExit()
        guard output.count <= 256 * 1024, !output.isEmpty else {
            throw NSError(domain:"OnlyPrivacy",code:1,userInfo:[NSLocalizedDescriptionKey:"지갑 프로그램을 열지 못했습니다. 설치 파일과 키체인 접근을 확인하세요."])
        }
        return output
    }
}

@MainActor final class WalletModel: ObservableObject {
    @Published var snapshot: WalletSnapshot?
    @Published var metadata = ""
    @Published var endpoint = ""
    @Published var message = "지갑을 열거나 새로 만드세요."
    @Published var busy = false
    @Published var invoice = ""
    @Published var invoiceFile = ""
    @Published var packetFile = ""
    @Published var recipientFile = ""
    @Published var address = ""
    @Published var amount = ""
    @Published var password = ""
    @Published var confirmation = ""
    @Published var creating = false
    @Published var tab = 0

    init() {
        if let data = try? Data(contentsOf:Bridge.root.appendingPathComponent("config/peers.json")),
           let peers = try? JSONDecoder().decode([String].self,from:data) { endpoint = peers.first ?? "" }
        if let previous = UserDefaults.standard.string(forKey:"OnlyPrivacy.walletMetadata"),
           FileManager.default.fileExists(atPath:previous) { metadata = previous }
        else {
            let local = Bundle.main.bundleURL.deletingLastPathComponent().appendingPathComponent("온리프라이버시_내지갑_100개/owner.json")
            if FileManager.default.fileExists(atPath:local.path) { metadata = local.path }
        }
    }
    func call(_ operation:String, extra:[String:String] = [:]) {
        guard !busy else { return }
        var input = extra; input["operation"] = operation
        if operation != "create" { input["metadata"] = metadata }
        guard let data = try? JSONSerialization.data(withJSONObject:input) else { return }
        busy = true; message = operation == "prepare" || operation == "renew" ? "비공개 거래 증명을 만들고 있습니다…" : "장부와 지갑을 확인하고 있습니다…"
        Task {
            do {
                let output = try await Task.detached(priority:.userInitiated) { try Bridge.invoke(data) }.value
                let result = try JSONDecoder().decode(BridgeReply.self,from:output)
                if result.ok {
                    if let state = result.snapshot { snapshot = state; metadata = state.metadata; UserDefaults.standard.set(metadata,forKey:"OnlyPrivacy.walletMetadata") }
                    if let value = result.invoice { invoice = value; invoiceFile = result.invoiceFile ?? "" }
                    if let file = result.packetFile { packetFile = file }
                    let messages = ["create":"새 지갑이 만들어졌습니다. 초기 잔액은 0 ONLYP입니다. 비밀번호와 지갑 파일을 보관하세요.",
                        "snapshot":"내 지갑을 확인했습니다. 잔액은 마지막으로 동기화한 장부 기준입니다.",
                        "invoice":"새 일회용 받는 주소입니다. 이번 송금의 상대방에게만 전달하세요.",
                        "prepare":"거래 파일을 만들었습니다. 아직 전송되지 않았습니다. 내용을 확인하고 노드에 제출하세요.",
                        "renew":"갱신 거래를 만들었습니다. 노드에 제출하고 블록에 포함되면 기존 노트는 재사용할 수 없습니다.",
                        "submit":"노드가 응답했습니다. 블록 포함 여부는 동기화 후 확인하세요.",
                        "sync":"장부를 독립 검증하고 잔액을 갱신했습니다."]
                    message = messages[operation] ?? "완료했습니다."
                    if operation == "create" { creating = false }
                } else { message = result.error ?? "지갑 작업을 완료하지 못했습니다." }
            } catch { message = error.localizedDescription }
            password = ""; confirmation = ""; busy = false
        }
    }
    func openWallet() {
        let panel = NSOpenPanel(); panel.title = "내 지갑 폴더의 owner.json 선택"
        panel.allowsMultipleSelection = false; panel.canChooseDirectories = false; panel.allowedContentTypes = [.json]
        if panel.runModal() == .OK, let url = panel.url {
            metadata = url.path; invoice = ""; invoiceFile = ""; packetFile = ""; snapshot = nil; call("snapshot")
        }
    }
    func createWallet() {
        guard password.count >= 12, password == confirmation else { message = "12글자 이상 비밀번호를 두 칸에 동일하게 입력하세요."; return }
        let panel = NSOpenPanel(); panel.title = "새 개인 지갑을 보관할 폴더 선택"
        panel.canChooseFiles = false; panel.canChooseDirectories = true; panel.canCreateDirectories = true
        if panel.runModal() == .OK, let parent = panel.url {
            let date = Int(Date().timeIntervalSince1970)
            let folder = parent.appendingPathComponent("OnlyPrivacy-Wallet-\(date)-\(UUID().uuidString.prefix(8))")
            call("create",extra:["directory":folder.path,"password":password])
        }
    }
    func chooseRecipient() {
        let panel = NSOpenPanel(); panel.title = "상대방의 새 일회용 주소 파일 선택"; panel.allowedContentTypes = [.json]
        if panel.runModal() == .OK, let url = panel.url { recipientFile = url.path }
    }
    func choosePacket() {
        let panel = NSOpenPanel(); panel.title = "제출할 공개 거래 파일 선택"; panel.allowedContentTypes = [.json]
        if panel.runModal() == .OK, let url = panel.url { packetFile = url.path }
    }
    func copy(_ text:String) { NSPasteboard.general.clearContents(); NSPasteboard.general.setString(text,forType:.string) }
    func reveal(_ file:String) { if !file.isEmpty { NSWorkspace.shared.activateFileViewerSelecting([URL(fileURLWithPath:file)]) } }
}

struct WalletView: View {
    @StateObject private var model = WalletModel()
    private let gold = Color(red:0.86,green:0.69,blue:0.31)
    private let panel = Color(red:0.075,green:0.08,blue:0.09)
    var body: some View {
        VStack(alignment:.leading,spacing:18) {
            HStack(spacing:15) {
                Image(nsImage:NSImage(contentsOf:Bundle.main.resourceURL!.appendingPathComponent("WalletLogo.png")) ?? NSImage())
                    .resizable().frame(width:66,height:66).cornerRadius(15)
                VStack(alignment:.leading,spacing:5) {
                    Text("ONLYPRIVACY").font(.system(size:25,weight:.bold,design:.rounded)).tracking(2)
                    Text("온리프라이버시 지갑").font(.subheadline).foregroundStyle(.secondary)
                }
                Spacer()
                Text("공개 시험망").font(.caption.weight(.semibold)).padding(.horizontal,13).padding(.vertical,7)
                    .background(gold.opacity(0.14)).foregroundStyle(gold).clipShape(Capsule())
            }
            HStack {
                Button("지갑 열기",action:model.openWallet)
                Button("새 지갑 만들기") { model.creating.toggle() }
                Spacer()
                if !model.metadata.isEmpty { Button("지갑 폴더") { model.reveal(model.metadata) } }
            }.disabled(model.busy)
            if model.creating { creation }
            HStack(alignment:.top,spacing:20) {
                VStack(alignment:.leading,spacing:12) {
                    Text("내 잔액").foregroundStyle(.secondary)
                    HStack(alignment:.firstTextBaseline,spacing:8) {
                        Text(model.snapshot?.total ?? "—").font(.system(size:44,weight:.semibold,design:.rounded)).foregroundStyle(gold)
                        Text("ONLYP").font(.headline).foregroundStyle(.secondary)
                    }
                    HStack(spacing:28) {
                        balanceItem("사용 가능",model.snapshot?.available)
                        balanceItem("전송 예약",model.snapshot?.reserved)
                        balanceItem("잠금",model.snapshot?.locked)
                    }
                }
                Spacer()
                VStack(alignment:.trailing,spacing:10) {
                    Text("장부 높이  \(model.snapshot?.height.description ?? "—")").font(.subheadline.monospacedDigit())
                    Text("수신 암호화  ML-KEM-1024").font(.caption).foregroundStyle(.secondary)
                    Button("잔액 새로 확인") { model.call("snapshot") }.disabled(model.busy || model.metadata.isEmpty)
                }
            }.padding(22).background(panel).clipShape(RoundedRectangle(cornerRadius:18))
            Picker("지갑 화면",selection:$model.tab) { Text("받기").tag(0); Text("보내기").tag(1); Text("장부 · 갱신").tag(2) }.pickerStyle(.segmented)
            Group {
                if model.tab == 0 { receive }
                else if model.tab == 1 { send }
                else { network }
            }.frame(maxWidth:.infinity,alignment:.leading).frame(minHeight:210,alignment:.top)
                .padding(20).background(panel).clipShape(RoundedRectangle(cornerRadius:18))
            HStack(alignment:.top,spacing:10) {
                if model.busy { ProgressView().controlSize(.small).padding(.top,2) }
                else { Image(systemName:"info.circle").foregroundStyle(gold).padding(.top,2) }
                Text(model.message).font(.callout).textSelection(.enabled).fixedSize(horizontal:false,vertical:true)
            }.frame(minHeight:36,alignment:.top)
            Spacer(minLength:0)
            Text("독립 체인 · 보안감사 전 시험 버전 · 일반 거래소·이더리움 주소 입금 지원 안 됨")
                .font(.caption).foregroundStyle(.secondary)
        }.padding(28).frame(minWidth:760,minHeight:730).background(Color(red:0.025,green:0.03,blue:0.038))
            .preferredColorScheme(.dark).tint(gold)
            .onAppear { if !model.metadata.isEmpty { model.call("snapshot") } }
    }
    func balanceItem(_ label:String,_ value:String?) -> some View {
        VStack(alignment:.leading,spacing:5) { Text(label).font(.caption).foregroundStyle(.secondary); Text(value ?? "—").font(.subheadline.monospacedDigit()) }
    }
    var creation: some View {
        VStack(alignment:.leading,spacing:10) {
            Text("새 참여 지갑 · 초기 잔액 0 ONLYP").font(.headline)
            SecureField("12글자 이상 비밀번호",text:$model.password)
            SecureField("비밀번호 다시 입력",text:$model.confirmation)
            HStack { Button("보관할 폴더 선택 후 만들기",action:model.createWallet); Text("비밀번호는 이 컴퓨터의 키체인에도 보관됩니다.").font(.caption).foregroundStyle(.secondary) }
        }.padding(15).background(panel).clipShape(RoundedRectangle(cornerRadius:12)).disabled(model.busy)
    }
    var receive: some View {
        HStack(alignment:.top,spacing:22) {
            VStack(alignment:.leading,spacing:13) {
                Text("매번 새로운 일회용 받는 주소").font(.headline)
                Text("주소 파일을 송신자에게 전달하세요. 개인키와 비밀번호는 전달하지 않습니다.").foregroundStyle(.secondary)
                Button("새 받는 주소 만들기") { model.call("invoice") }.disabled(model.busy || model.metadata.isEmpty)
                if !model.invoice.isEmpty {
                    HStack { Button("주소 복사") { model.copy(model.invoice) }; Button("주소 파일 보기") { model.reveal(model.invoiceFile) } }
                    Text("이번 송금에만 사용하세요.").font(.caption).foregroundStyle(gold)
                }
            }
            Spacer()
            if let qr = qrImage(model.invoice) {
                Image(nsImage:qr).interpolation(.none).resizable().frame(width:178,height:178).padding(10).background(.white).cornerRadius(12)
            }
        }
    }
    var send: some View {
        VStack(alignment:.leading,spacing:12) {
            TextField("상대방의 onlyprivacy:v1:… 일회용 주소 붙여넣기",text:$model.address)
            HStack { Button("상대방 주소 파일 선택",action:model.chooseRecipient); Text(model.recipientFile.isEmpty ? "새 일회용 주소가 필요합니다" : URL(fileURLWithPath:model.recipientFile).lastPathComponent).foregroundStyle(.secondary) }
            HStack { TextField("보낼 ONLYP 수량",text:$model.amount).frame(maxWidth:240); Text("수수료 0.000001 ONLYP 별도").font(.caption).foregroundStyle(.secondary) }
            Button("거래 파일 만들기") { model.call("prepare",extra:["recipientFile":model.recipientFile,"address":model.address.trimmingCharacters(in:.whitespacesAndNewlines),"amount":model.amount]) }.disabled(model.metadata.isEmpty || (model.recipientFile.isEmpty && model.address.isEmpty) || model.amount.isEmpty)
            Divider()
            HStack { Button("거래 파일 선택",action:model.choosePacket); Text(model.packetFile.isEmpty ? "준비된 거래가 없습니다" : URL(fileURLWithPath:model.packetFile).lastPathComponent).font(.caption).lineLimit(1) }
            HStack { TextField("참여 노드의 http://…onion/ 주소",text:$model.endpoint); Button("노드에 제출") { model.call("submit",extra:["packetFile":model.packetFile,"endpoint":model.endpoint]) }.disabled(model.packetFile.isEmpty || model.endpoint.isEmpty) }
            Text("블록에 포함된 뒤 장부를 동기화하면 잔액이 확정됩니다. Tor 연결이 필요합니다.").font(.caption).foregroundStyle(.secondary)
        }.disabled(model.busy)
    }
    var network: some View {
        VStack(alignment:.leading,spacing:12) {
            Text("공개 장부 동기화").font(.headline)
            HStack { TextField("http://…onion/ 노드 주소",text:$model.endpoint); Button("동기화") { model.call("sync",extra:["endpoint":model.endpoint]) }.disabled(model.endpoint.isEmpty || model.metadata.isEmpty) }
            Text("Tor SOCKS 19050이 필요합니다. 노드공유.command 또는 채굴 메뉴에서 연결할 수 있습니다.").font(.caption).foregroundStyle(.secondary)
            Divider()
            HStack { Button("보관 코인 갱신 거래 만들기") { model.call("renew") }.disabled(model.metadata.isEmpty); Text("최대 2개 노트 · 수수료 0.000001 ONLYP").font(.caption).foregroundStyle(.secondary) }
            Text("갱신도 만든 거래 파일을 제출해야 합니다. 기존 입력은 한 번만 사용할 수 있습니다.").font(.caption).foregroundStyle(.secondary)
            if let state = model.snapshot { Text("제네시스  \(state.genesis)").font(.system(size:10,design:.monospaced)).textSelection(.enabled) }
        }.disabled(model.busy)
    }
    func qrImage(_ text:String) -> NSImage? {
        guard !text.isEmpty else { return nil }
        let filter = CIFilter.qrCodeGenerator(); filter.message = Data(text.utf8); filter.correctionLevel = "L"
        guard let image = filter.outputImage, let bitmap = CIContext().createCGImage(image,from:image.extent) else { return nil }
        return NSImage(cgImage:bitmap,size:NSSize(width:bitmap.width,height:bitmap.height))
    }
}

@main struct OnlyPrivacyWalletApp: App {
    init() {
        if CommandLine.arguments.count == 3 && CommandLine.arguments[1] == "--self-check" {
            do {
                let input = try JSONSerialization.data(withJSONObject:["operation":"snapshot","metadata":CommandLine.arguments[2]])
                let output = try Bridge.invoke(input)
                FileHandle.standardOutput.write(output); exit(0)
            } catch { fputs("Wallet self-check failed\n",stderr); exit(1) }
        }
    }
    var body: some Scene {
        WindowGroup("온리프라이버시 지갑") { WalletView() }.defaultSize(width:840,height:780)
            .windowResizability(.contentMinSize)
    }
}
