import AppKit
let directory = URL(fileURLWithPath:CommandLine.arguments[1],isDirectory:true)
try FileManager.default.createDirectory(at:directory,withIntermediateDirectories:true)
func render(_ size:Int) throws -> Data {
    let bitmap = NSBitmapImageRep(bitmapDataPlanes:nil,pixelsWide:size,pixelsHigh:size,bitsPerSample:8,samplesPerPixel:4,hasAlpha:true,isPlanar:false,colorSpaceName:.deviceRGB,bytesPerRow:0,bitsPerPixel:0)!
    NSGraphicsContext.saveGraphicsState(); defer { NSGraphicsContext.restoreGraphicsState() }
    NSGraphicsContext.current = NSGraphicsContext(bitmapImageRep:bitmap)
    let c = NSGraphicsContext.current!.cgContext; c.scaleBy(x:CGFloat(size)/512,y:CGFloat(size)/512)
    c.setFillColor(NSColor(red:0.031,green:0.035,blue:0.043,alpha:1).cgColor)
    c.addPath(CGPath(roundedRect:CGRect(x:0,y:0,width:512,height:512),cornerWidth:92,cornerHeight:92,transform:nil)); c.fillPath()
    c.setStrokeColor(NSColor(red:0.733,green:0.569,blue:0.243,alpha:1).cgColor); c.setLineWidth(2)
    c.addPath(CGPath(roundedRect:CGRect(x:17,y:17,width:478,height:478),cornerWidth:78,cornerHeight:78,transform:nil)); c.strokePath()
    c.saveGState(); c.translateBy(x:0,y:512); c.scaleBy(x:1,y:-1)
    let p = CGMutablePath();p.move(to:CGPoint(x:112,y:432));p.addLine(to:CGPoint(x:112,y:80));p.addLine(to:CGPoint(x:270,y:80))
    p.addCurve(to:CGPoint(x:416,y:206),control1:CGPoint(x:370,y:80),control2:CGPoint(x:416,y:120))
    p.addCurve(to:CGPoint(x:270,y:326),control1:CGPoint(x:416,y:286),control2:CGPoint(x:360,y:326))
    p.addLine(to:CGPoint(x:190,y:326));p.addLine(to:CGPoint(x:190,y:432));p.closeSubpath()
    p.move(to:CGPoint(x:190,y:142));p.addLine(to:CGPoint(x:190,y:266));p.addLine(to:CGPoint(x:266,y:266))
    p.addCurve(to:CGPoint(x:344,y:206),control1:CGPoint(x:322,y:266),control2:CGPoint(x:344,y:248))
    p.addCurve(to:CGPoint(x:266,y:142),control1:CGPoint(x:344,y:164),control2:CGPoint(x:322,y:142));p.closeSubpath()
    c.addPath(p);c.clip(using:.evenOdd)
    let colors = [NSColor(red:1,green:0.906,blue:0.627,alpha:1).cgColor,NSColor(red:0.847,green:0.678,blue:0.306,alpha:1).cgColor,NSColor(red:0.659,green:0.451,blue:0.11,alpha:1).cgColor] as CFArray
    c.drawLinearGradient(CGGradient(colorsSpace:CGColorSpaceCreateDeviceRGB(),colors:colors,locations:[0,0.45,1])!,start:CGPoint(x:112,y:80),end:CGPoint(x:416,y:432),options:[])
    c.restoreGState()
    let font = NSFont(name:"Georgia-Bold",size:120) ?? NSFont.boldSystemFont(ofSize:120)
    let glyph = font.glyph(withName:"s"), advance = font.advancement(forGlyph:glyph).width
    let letter = NSBezierPath();letter.move(to:NSPoint(x:267-advance/2,y:271));letter.appendGlyph(glyph,in:font)
    NSColor(red:0.94,green:0.76,blue:0.40,alpha:1).setFill();letter.fill()
    return bitmap.representation(using:.png,properties:[:])!
}
for size in [16,32,64,128,256,512,1024] { try render(size).write(to:directory.appendingPathComponent("logo-\(size).png")) }
