import test from 'node:test';
import assert from 'node:assert/strict';
import {generateKeyPairSync} from 'node:crypto';
import {Wallet} from '../src/wallet.mjs';
import {initialize,randomField} from '../src/primitives.mjs';
import {encodeAddress,decodeAddress} from '../src/addresses.mjs';
await initialize();
const domain=randomField();
test('cryptographic one-time addresses preserve only public recipient data',()=>{
 const wallet=new Wallet(),invoice=wallet.invoice(domain),address=encodeAddress(invoice);
 assert.deepEqual(decodeAddress(address,domain),invoice);assert.ok(address.length<2900);
 const entry=wallet.data.invoices[0];assert.equal(address.includes(entry.privateKey),false);assert.equal(address.includes(entry.secret),false);
});
test('each newly generated address has a fresh owner and ML-KEM key',()=>{
 const wallet=new Wallet(),a=wallet.invoice(domain),b=wallet.invoice(domain);
 assert.notEqual(a.owner,b.owner);assert.notEqual(a.publicKey,b.publicKey);assert.notEqual(encodeAddress(a),encodeAddress(b));
});
test('address checksum detects mutation and wrong network is rejected',()=>{
 const address=encodeAddress(new Wallet().invoice(domain));
 const changed=address.slice(0,50)+(address[50]==='A'?'B':'A')+address.slice(51);
 assert.throws(()=>decodeAddress(changed));assert.throws(()=>decodeAddress(address,randomField()),/another OnlyPrivacy network/);
});
test('noncanonical encodings and unsupported prefixes do not decode',()=>{
 const address=encodeAddress(new Wallet().invoice(domain));
 for(const text of [address+'=',address+' ',address.replace('v1:','v2:'),'https://example.invalid/'+address,'onlyprivacy:v1:AA'])assert.throws(()=>decodeAddress(text));
});
test('classical or mismatched public keys cannot masquerade as ML-KEM addresses',()=>{
 const invoice=new Wallet().invoice(domain),pair=generateKeyPairSync('ed25519');
 assert.throws(()=>encodeAddress({...invoice,publicKey:pair.publicKey.export({type:'spki',format:'der'}).toString('base64')}),/wrong encryption suite/);
 assert.throws(()=>encodeAddress({...invoice,suite:1}),/wrong encryption suite/);
});
