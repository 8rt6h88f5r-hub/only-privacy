import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {execFile} from 'node:child_process';
import {PROJECT} from '../src/proofs.mjs';
const call=data=>new Promise((resolve,reject)=>{const p=execFile(process.execPath,['scripts/wallet-bridge.mjs'],{cwd:PROJECT,env:{},maxBuffer:1024*1024,timeout:10000},(_error,stdout)=>{try{resolve(JSON.parse(stdout));}catch{reject(Error('Bridge did not return bounded JSON'));}});p.stdin.end(JSON.stringify(data));});
test('native wallet bridge has no arbitrary command or process execution interface',async()=>{
 const reply=await call({operation:'exec',command:'whoami'});assert.equal(reply.ok,false);assert.match(reply.error,/Unsupported wallet operation/);
});
test('native wallet bridge refuses foreign metadata before opening any Keychain item',async()=>{
 const dir=await fs.mkdtemp(path.join(os.tmpdir(),'onlyprivacy-bridge-'));const file=path.join(dir,'owner.json');
 try{await fs.writeFile(file,JSON.stringify({version:1,coin:'OnlyPrivacy',wallet:'../../other',chain:'chain.json',genesis:'bad',keychainService:'unrelated-service'}),{mode:0o600});const reply=await call({operation:'snapshot',metadata:file});assert.equal(reply.ok,false);assert.match(reply.error,/Incompatible wallet metadata/);}finally{await fs.rm(dir,{recursive:true,force:true});}
});
test('native wallet bridge refuses to create private custody inside distributable program source',async()=>{
 const reply=await call({operation:'create',directory:path.join(PROJECT,'private-wallet'),password:'example-password-only-for-validation'});assert.equal(reply.ok,false);assert.match(reply.error,/outside the distributed program/);
 assert.equal(await fs.access(path.join(PROJECT,'private-wallet')).then(()=>true,()=>false),false);
});
