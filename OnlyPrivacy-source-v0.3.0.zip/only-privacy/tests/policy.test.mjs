import test from 'node:test';
import assert from 'node:assert/strict';
import { ANNUAL,INITIAL,UNIT,YEAR,baseReward,subsidy,parseAmount,formatAmount } from '../src/emission.mjs';
import { encryptWallet,decryptWallet,invoiceKeyPair,sealNote,openNote } from '../src/envelopes.mjs';
import { onionEndpoint,fetchPeerChain } from '../src/transport.mjs';
import { checkArtifacts } from '../src/security.mjs';
import { RandomX } from '../src/pow.mjs';
test('exact integer denominations and monetary constitution',()=>{
  assert.equal(INITIAL,10000n*UNIT);assert.equal(ANNUAL,100n*UNIT);
  assert.equal(parseAmount('12.345678901234'),12345678901234n);
  assert.equal(formatAmount(12345678901234n),'12.345678901234');
  for(const text of ['-1','1e3','NaN','0.0000000000001','01','1.'])assert.throws(()=>parseAmount(text));
});
test('scheduled first-year emission is exactly one hundred and inflation declines',()=>{
  let sum=0n;for(let h=1;h<=262800;h++)sum+=baseReward(h);assert.equal(sum,ANNUAL);
  let prior=1.01;for(let n=0;n<10000;n++){const rate=100/(10000+100*n);assert.ok(rate<=0.01&&rate<prior);prior=rate;}
});
test('fast blocks cannot get beyond time credit or rolling issuance cap',()=>{
  const genesis={timestamp:100,subsidy:INITIAL.toString()};assert.equal(subsidy([genesis],100),0n);
  assert.ok(subsidy([genesis],101)<=ANNUAL/BigInt(YEAR));
  const full=[genesis,{timestamp:100+YEAR-1,subsidy:ANNUAL.toString()}];
  assert.equal(subsidy(full,100+YEAR+1),0n);
  assert.ok(subsidy(full,100+2*YEAR-1)>0n);
});
test('wallet encryption authenticates contents and rejects wrong passwords',()=>{
  const data={privateKey:'ephemeral-test-secret',notes:[]};
  const box=encryptWallet(data,'correct horse battery staple');
  assert.ok(!JSON.stringify(box).includes(data.privateKey));
  assert.equal(decryptWallet(box,'correct horse battery staple').privateKey,data.privateKey);
  assert.throws(()=>decryptWallet(box,'incorrect password'));
  const changed=structuredClone(box);changed.data=Buffer.alloc(Buffer.from(box.data,'base64').length).toString('base64');
  assert.throws(()=>decryptWallet(changed,'correct horse battery staple'));
});
for(const suite of [1,2])test('ML-KEM authenticated note encryption, suite '+suite,()=>{
  const a=invoiceKeyPair(suite),b=invoiceKeyPair(suite),invoice={suite,publicKey:a.publicKey};
  const note={owner:'123',value:'456',rho:'789',lock:'0',memo:'private'};
  const box=sealNote(note,invoice,'domain','commitment');
  assert.equal(openNote(box,a.privateKey,'domain','commitment').memo,'private');
  assert.equal(openNote(box,b.privateKey,'domain','commitment'),null);
  assert.equal(openNote(box,a.privateKey,'other-domain','commitment'),null);
  assert.equal(openNote(box,a.privateKey,'domain','other-commitment'),null);
  assert.equal(Buffer.from(box.data,'base64').length,1024);
});
test('transport rejects public IPs/domains and fails without Tor',async()=>{
  for(const u of ['http://127.0.0.1/','http://example.com/','https://example.com/'])assert.throws(()=>onionEndpoint(u));
  const onion='http://'+'a'.repeat(56)+'.onion/';assert.equal(onionEndpoint(onion).host,'a'.repeat(56)+'.onion');
  await assert.rejects(fetchPeerChain(onion,{proxyPort:1}));
});
test('fixed STARK program and compiler lock match the manifest',async()=>{
  const result=await checkArtifacts();assert.equal(result.ok,true);assert.equal(result.administratorKey,false);assert.equal(result.postQuantumDesign,true);assert.equal(result.absoluteQuantumSecurityProof,false);assert.equal(result.trustedSetup,false);
});
test('native RandomX matches the upstream reference vector',()=>{
  const engine=new RandomX();
  try{assert.equal(engine.hashBytes(Buffer.from('This is a test'),Buffer.from('test key 000')),'639183aae1bf4c9a35884cb46b09cad9175f04efd7684e7262a0ac1c2f0b4e3f');}
  finally{engine.close();}
});
