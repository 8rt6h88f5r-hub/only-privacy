import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';
import net from 'node:net';
import { fetchPeerChain } from '../src/transport.mjs';
import { startSocks } from './helpers/socks.mjs';

test('onion HTTP uses SOCKS authentication isolation and has no direct fallback',{timeout:10000},async()=>{
  let request='';
  const server=http.createServer((req,res)=>{request=req.url;res.end(JSON.stringify({test:'through-socks'}));});
  await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
  const hostname='a'.repeat(56)+'.onion',proxy=await startSocks({[hostname]:server.address().port});
  try{
    for(let i=0;i<2;i++)assert.equal((await fetchPeerChain('http://'+hostname+'/',{proxyPort:proxy.port})).test,'through-socks');
    assert.equal(request,'/chain');assert.equal(proxy.requests.length,2);assert.equal(proxy.requests[0].hostname,hostname);
    assert.notEqual(proxy.requests[0].credentials,proxy.requests[1].credentials);
  }finally{await proxy.close();await new Promise(resolve=>server.close(resolve));}
});

test('SOCKS proxy without authentication isolation is rejected',{timeout:10000},async()=>{
  const proxy=net.createServer(socket=>{socket.on('data',()=>socket.end(Buffer.from([5,0])));});
  await new Promise(resolve=>proxy.listen(0,'127.0.0.1',resolve));
  try{await assert.rejects(fetchPeerChain('http://'+'a'.repeat(56)+'.onion/',{proxyPort:proxy.address().port}),/isolation/);}
  finally{await new Promise(resolve=>proxy.close(resolve));}
});
