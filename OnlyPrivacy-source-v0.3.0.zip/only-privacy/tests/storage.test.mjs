import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { once } from 'node:events';
import { exclusive,writeJSON,readJSON } from '../src/storage.mjs';
import { Wallet } from '../src/wallet.mjs';

test('durable private writes preserve the old file on serialization failure and refuse overwrite',async()=>{
  const dir=await fs.mkdtemp(path.join(os.tmpdir(),'ipc-storage-')),file=path.join(dir,'private.json');
  try{
    await writeJSON(file,{value:'old'});const circular={};circular.self=circular;
    await assert.rejects(writeJSON(file,circular));assert.deepEqual(await readJSON(file),{value:'old'});
    await assert.rejects(writeJSON(file,{value:'new'},0o600,{replace:false}),/EEXIST/);
    assert.deepEqual(await readJSON(file),{value:'old'});assert.equal((await fs.stat(file)).mode&0o077,0);
    assert.equal((await fs.readdir(dir)).filter(x=>x.endsWith('.tmp')).length,0);
  }finally{await fs.rm(dir,{recursive:true,force:true});}
});

test('rejected wallet passwords do not leave an empty file or overwrite a wallet',async()=>{
  const dir=await fs.mkdtemp(path.join(os.tmpdir(),'ipc-new-wallet-')),file=path.join(dir,'wallet.enc.json');
  try {
    await assert.rejects(Wallet.create(file,'short'),/at least 12/);
    await assert.rejects(fs.access(file));
    await Wallet.create(file,'correct horse battery staple');const before=await fs.readFile(file,'utf8');
    await assert.rejects(Wallet.create(file,'another strong password'),/EEXIST/);
    assert.equal(await fs.readFile(file,'utf8'),before);
  }finally{await fs.rm(dir,{recursive:true,force:true});}
});

test('OS lock excludes another process and releases after SIGKILL',{timeout:10000},async()=>{
  const dir=await fs.mkdtemp(path.join(os.tmpdir(),'ipc-lock-')),file=path.join(dir,'chain.json');
  const module=new URL('../src/storage.mjs',import.meta.url).href;
  const child=spawn(process.execPath,['--input-type=module','-e',
    'import {exclusive} from '+JSON.stringify(module)+';await exclusive(process.argv[1],async()=>{process.stdout.write("locked\\n");await new Promise(()=>{setInterval(()=>{},1000);});});',file],{stdio:['ignore','pipe','pipe']});
  try {
    const [message]=await once(child.stdout,'data');assert.match(message.toString(),/locked/);
    await assert.rejects(exclusive(file,async()=>{}),/in use/);
    const exited=once(child,'exit');child.kill('SIGKILL');await exited;
    let acquired=false;await exclusive(file,async()=>{acquired=true;});assert.equal(acquired,true);
    assert.equal((await fs.stat(file+'.lock')).isFile(),true);
  }finally{child.kill('SIGKILL');await fs.rm(dir,{recursive:true,force:true});}
});
