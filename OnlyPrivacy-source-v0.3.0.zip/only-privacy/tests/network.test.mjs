import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { once } from 'node:events';
import { randomBytes } from 'node:crypto';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { Wallet } from '../src/wallet.mjs';
import { Chain } from '../src/chain.mjs';
import { PublicNode,transactionPacket } from '../src/node.mjs';
import { serveNode,submitTransaction } from '../src/transport.mjs';
import { peerCycle } from '../src/peers.mjs';
import { buildTransaction } from '../src/transactions.mjs';
import { readJSON,writeJSON } from '../src/storage.mjs';
import { parseAmount } from '../src/emission.mjs';
import { PROJECT } from '../src/proofs.mjs';
import { startSocks } from './helpers/socks.mjs';
const run=promisify(execFile);

test('independent sender, two public nodes and a separate CPU miner settle a private payment',{timeout:360000},async t=>{
  const dir=await fs.mkdtemp(path.join(os.tmpdir(),'ipc-network-'));
  const fileA=path.join(dir,'a.chain.json'),fileB=path.join(dir,'b.chain.json'),minerChain=path.join(dir,'miner.chain.json');
  const aliceFile=path.join(dir,'alice.wallet.enc.json'),minerFile=path.join(dir,'miner.wallet.enc.json');
  const recipientFile=path.join(dir,'recipient.json'),txFile=path.join(dir,'transaction.json');
  const password=randomBytes(32).toString('hex');
  let a,b,proxy,serverA,serverB,genesis,candidate;
  try {
    const alice=await Wallet.create(aliceFile,password),bob=new Wallet();
    genesis=await Chain.create(alice,{timestamp:Math.floor(Date.now()/1000)-600});
    await alice.save(aliceFile,password);const before=structuredClone(alice.data);
    for(const file of [fileA,fileB,minerChain])await genesis.save(file);
    const recipient=bob.invoice(genesis.config.domain);await writeJSON(recipientFile,recipient);
    await Wallet.create(minerFile,password);
    a=await PublicNode.open(fileA);b=await PublicNode.open(fileB);
    serverA=serveNode(a,{port:0});serverB=serveNode(b,{port:0});await Promise.all([once(serverA,'listening'),once(serverB,'listening')]);
    const hostA='a'.repeat(56)+'.onion',hostB='b'.repeat(56)+'.onion';
    proxy=await startSocks({[hostA]:serverA.address().port,[hostB]:serverB.address().port});
    const endpointA='http://'+hostA+'/',endpointB='http://'+hostB+'/',options={proxyPort:proxy.port};
    const env={...process.env,IPC_WALLET_PASSWORD:password,IPC_TOR_PROXY_PORT:String(proxy.port)};
    const cli=async args=>JSON.parse((await run(process.execPath,['src/cli.mjs',...args],{cwd:PROJECT,env,timeout:180000,maxBuffer:1024*1024})).stdout);
    let packet;
    await t.test('wallet exports only the public proof transaction and reserves its input',async()=>{
      const result=await cli(['prepare',recipientFile,'18.75',aliceFile,fileA,txFile]);
      packet=await readJSON(txFile);assert.equal(result.transaction.length,64);assert.equal(packet.protocol,'onlyprivacy-transaction-v1');
      const publicText=JSON.stringify(packet);
      for(const invoice of alice.data.invoices){assert.equal(publicText.includes(invoice.privateKey),false);assert.equal(publicText.includes(invoice.invoice.publicKey),false);}
      assert.equal(publicText.includes(recipient.publicKey),false);assert.equal(publicText.includes('18.75'),false);
      const reloaded=await Wallet.load(aliceFile,password);reloaded.scan(a.chain);assert.equal(reloaded.data.pending.length,1);
      assert.equal(reloaded.balance(1).available,0n);assert.equal(reloaded.balance(1).reserved,parseAmount('100'));
      assert.throws(()=>reloaded.select(1n,1),/Insufficient/);
    });
    await t.test('pending storage failure does not acknowledge or retain a transaction',async()=>{
      a.persist=async(file,data)=>{if(file===fileA+'.pending.json')throw Error('Injected pending storage failure');return writeJSON(file,data);};
      await assert.rejects(a.acceptTransaction(packet),/storage failure/);assert.equal(a.pool.size,0);a.persist=writeJSON;
    });
    await t.test('node validates proofs, persists pending transactions and rejects conflicts',async()=>{
      const invalid=structuredClone(packet);const badBytes=Buffer.from(invalid.transaction.proof.bytes,'base64');badBytes[120]^=1;invalid.transaction.proof.bytes=badBytes.toString('base64');
      await assert.rejects(submitTransaction(endpointA,invalid,options));assert.equal(a.pool.size,0);
      assert.equal((await cli(['submit',txFile,endpointA])).accepted,true);assert.equal(a.pool.size,1);
      assert.equal((await submitTransaction(endpointA,packet,options)).known,true);
      const conflict=await buildTransaction(a.chain,new Wallet(before),{recipient:bob.invoice(a.chain.config.domain),amount:parseAmount('2')});
      await assert.rejects(a.acceptTransaction(transactionPacket(a.chain,conflict)),/Double spend/);
      await assert.rejects(a.acceptTransaction({...packet,genesis:'0'.repeat(64)}),/another network/);
      const reopened=await PublicNode.open(fileA);assert.equal(reopened.pool.size,1);reopened.close();
      const response=await fetch('http://127.0.0.1:'+serverA.address().port+'/pending',{headers:{Origin:'https://untrusted.example'}});assert.equal(response.status,403);
    });
    await t.test('configured nodes propagate validated pending transactions through SOCKS',async()=>{
      assert.equal(b.pool.size,0);const result=await peerCycle(b,endpointA,options);
      assert.equal(result.received,1);assert.equal(b.pool.size,1);
    });
    await t.test('independent miner receives no sender keys and returns a verified block',async()=>{
      const result=await cli(['mine-remote',endpointB,minerFile,minerChain]);
      assert.equal(result.published,true);assert.equal(result.transactions,1);assert.equal(b.chain.height,1);assert.equal(b.pool.size,0);
      assert.equal((await readJSON(result.blockFile)).id,b.chain.blocks.at(-1).id);
      assert.equal(bob.scan(b.chain).total,parseAmount('18.75'));
      const miner=await Wallet.load(minerFile,password);assert.ok(miner.scan(b.chain).total>0n);
      assert.equal(miner.data.invoices.some(entry=>before.invoices.some(old=>old.secret===entry.secret)),false);
    });
    await t.test('higher-work synchronization clears confirmed transactions and reservations',async()=>{
      const result=await peerCycle(a,endpointB,options);assert.equal(result.adopted,true);assert.equal(a.chain.height,1);assert.equal(a.pool.size,0);
      const sender=await Wallet.load(aliceFile,password);sender.scan(a.chain);assert.equal(sender.data.pending.length,0);assert.equal(sender.balance(2).reserved,0n);
      assert.equal(a.chain.blocks.at(-1).id,b.chain.blocks.at(-1).id);
      const saved=await Chain.load(fileA);assert.equal(saved.height,1);saved.close();
    });
    await t.test('long-held notes renew to fresh current-suite outputs and wallet copies do not duplicate coins',async()=>{
      const renewalFile=path.join(dir,'renewal.json');const renewal=await cli(['renew',aliceFile,fileA,renewalFile]);
      assert.equal(renewal.suite,2);assert.equal(renewal.inputsRenewed,1);
      const renewed=await readJSON(renewalFile);assert.equal((await a.acceptTransaction(renewed)).accepted,true);
      const result=await cli(['mine-remote',endpointA,minerFile,minerChain]);assert.equal(result.published,true);
      const sender=await Wallet.load(aliceFile,password);sender.scan(a.chain);assert.equal(sender.balance(3).total,parseAmount('81.249998'));
      const oldCopy=new Wallet(before);assert.equal(oldCopy.scan(a.chain).total,0n);
      assert.equal(sender.data.pending.length,0);assert.equal(renewed.transaction.external.suite,a.chain.activeSuite());
    });
    await t.test('failed block persistence leaves the live tip and saved chain unchanged',async()=>{
      candidate=a.chain.fork();const block=await candidate.mine(new Wallet(),[],{maxAttempts:10});
      const previous=a.chain.blocks.at(-1).id,oldFile=await fs.readFile(fileA,'utf8');
      a.persist=async(file,data)=>{if(file===fileA)throw Error('Injected disk failure');return writeJSON(file,data);};
      await assert.rejects(a.acceptBlock(block),/disk failure/);
      assert.equal(a.chain.blocks.at(-1).id,previous);assert.equal(await fs.readFile(fileA,'utf8'),oldFile);
      a.persist=writeJSON;assert.equal((await a.acceptBlock(block)).accepted,true);assert.equal(a.chain.height,3);
    });
    await t.test('uncertain directory persistence halts writes and preserves the visible chain tip',async()=>{
      candidate.close();candidate=a.chain.fork();const block=await candidate.mine(new Wallet(),[],{maxAttempts:10});
      a.persist=async(file,data)=>{await writeJSON(file,data);if(file===fileA){const error=Error('Injected directory synchronization failure');error.replacementVisible=true;throw error;}};
      await assert.rejects(a.acceptBlock(block),/synchronization failure/);assert.equal(a.halted,true);
      const visible=await Chain.load(fileA);assert.equal(a.chain.blocks.at(-1).id,visible.blocks.at(-1).id);visible.close();
      await assert.rejects(a.acceptBlock(block),/restart and revalidate/);
      const restarted=await PublicNode.open(fileA);assert.equal(restarted.chain.height,4);assert.equal(restarted.halted,false);restarted.close();
    });
    assert.ok(proxy.requests.length>=10);
    assert.equal(new Set(proxy.requests.map(r=>r.credentials)).size,proxy.requests.length);
  }finally{
    await proxy?.close();for(const server of [serverA,serverB])if(server)await new Promise(resolve=>server.close(resolve));
    a?.close();b?.close();genesis?.close();candidate?.close();await fs.rm(dir,{recursive:true,force:true});
  }
});
