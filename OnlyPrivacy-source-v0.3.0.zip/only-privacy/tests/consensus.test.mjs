import test from 'node:test';
import assert from 'node:assert/strict';
import { Wallet } from '../src/wallet.mjs';
import { Chain } from '../src/chain.mjs';
import { buildTransaction } from '../src/transactions.mjs';
import { verify } from '../src/proofs.mjs';
import { fieldHash,sha } from '../src/primitives.mjs';
import { miningKey } from '../src/pow.mjs';
import { UNIT,INITIAL,OWNER_ALLOCATION,MINER_RESERVE,reserveReward,YEAR,ANNUAL,subsidy,baseReward,RESERVE_BLOCKS } from '../src/emission.mjs';

test('fixed issuance, reserved supply and ten-year integer allocation',()=>{
  assert.equal(OWNER_ALLOCATION+MINER_RESERVE,INITIAL);assert.equal(OWNER_ALLOCATION,100n*UNIT);
  let total=0n;for(let h=1;h<=RESERVE_BLOCKS;h++)total+=BigInt(h)*MINER_RESERVE/BigInt(RESERVE_BLOCKS)-BigInt(h-1)*MINER_RESERVE/BigInt(RESERVE_BLOCKS);
  assert.equal(total,MINER_RESERVE);
  const delayed=Array(RESERVE_BLOCKS+1).fill({timestamp:101,subsidy:'0',reserveRelease:'0'});delayed[0]={timestamp:100,subsidy:INITIAL.toString(),reserveRelease:'0'};
  assert.ok(reserveReward(delayed,100+YEAR*10)>0n,'An unspent reserve remains distributable after the target block count');
  const history=[{timestamp:100,subsidy:INITIAL.toString(),reserveRelease:'0'}];
  assert.equal(reserveReward(history,100),0n);
  assert.ok(reserveReward(history,101)<=MINER_RESERVE/BigInt(YEAR*10));
  assert.equal(reserveReward([...history,{timestamp:220,subsidy:'1',reserveRelease:MINER_RESERVE.toString()}],YEAR*10+100),0n);
  let annual=0n;for(let h=1;h<=262800;h++)annual+=baseReward(h);assert.equal(annual,ANNUAL);
  assert.ok(subsidy(history,101)<=ANNUAL/BigInt(YEAR));
});

test('transparent STARK payment and consensus refuse unauthorized changes',{timeout:300000},async t=>{
  const owner=new Wallet(),recipient=new Wallet(),miner=new Wallet(),outsider=new Wallet();
  const chain=await Chain.create(owner,{timestamp:Math.floor(Date.now()/1000)-600});t.after(()=>chain.close());
  await t.test('100 privately spendable and 9900 controlled by protocol, with no reserve key',()=>{
    assert.equal(owner.scan(chain).total,OWNER_ALLOCATION);assert.equal(chain.supply,INITIAL);
    assert.equal(chain.reserveRemaining,MINER_RESERVE);assert.equal(chain.circulating,OWNER_ALLOCATION);
    assert.equal(chain.blocks[0].transactions[0].publicSignals[7],OWNER_ALLOCATION.toString());
    assert.equal(chain.config.minerReserve,MINER_RESERVE.toString());assert.equal(outsider.scan(chain).total,0n);
  });
  const invoice=recipient.invoice(chain.config.domain,2);
  const transaction=await buildTransaction(chain,owner,{recipient:invoice,amount:3n*UNIT,memo:'ONLYPRIVACY_SECRET_MEMO'});
  await t.test('real STARK verifies without a trusted setup and hides values and keys',async()=>{
    assert.equal(transaction.proof.system,'triton-stark-v1');assert.equal(await verify(transaction.proof,transaction.publicSignals),true);
    const text=JSON.stringify(transaction);assert.equal(text.includes('ONLYPRIVACY_SECRET_MEMO'),false);assert.equal(text.includes(invoice.publicKey),false);
    for(const n of owner.data.notes)assert.equal(text.includes(n.secret),false);
  });
  await t.test('changed public mint and mutated proof are rejected',async()=>{
    const signals=[...transaction.publicSignals];signals[7]='1';assert.equal(await verify(transaction.proof,signals),false);
    const proof=structuredClone(transaction.proof),bytes=Buffer.from(proof.bytes,'base64');bytes[120]^=1;proof.bytes=bytes.toString('base64');assert.equal(await verify(proof,transaction.publicSignals),false);
  });
  await t.test('ciphertext substitution with a recalculated public envelope hash is rejected',async()=>{
    const changed=structuredClone(transaction);changed.external.nonce='a'.repeat(64);changed.publicSignals[9]=fieldHash(changed.external);
    await assert.rejects(chain.validateTransaction(changed),/proof/);
  });
  const block=await chain.mine(miner,[transaction],{maxAttempts:10});
  await t.test('independent miner receives reserve, new issuance and fee, with no sender key',()=>{
    const reserve=BigInt(block.header.reserveRelease),fresh=BigInt(block.header.subsidy);
    assert.equal(miner.scan(chain).total,reserve+fresh+1000000n);assert.ok(reserve>0n);
    assert.equal(recipient.scan(chain).total,3n*UNIT);assert.equal(chain.reserveRemaining,MINER_RESERVE-reserve);
    assert.equal(chain.supply,INITIAL+fresh);assert.equal(chain.circulating,OWNER_ALLOCATION+reserve+fresh);
  });
  await t.test('complete public history replays independently',async()=>{
    const other=await Chain.fromData(structuredClone(chain.data()));try{assert.equal(other.blocks.at(-1).id,block.id);}finally{other.close();}
  });
  await t.test('developer cannot change monetary constants or reserve and retain the network',async()=>{
    for(const key of ['annual','ownerAllocation','minerReserve']){
      const changed=structuredClone(chain.data());changed.config[key]=(BigInt(changed.config[key])+1n).toString();await assert.rejects(Chain.fromData(changed));
    }
    const changed=structuredClone(chain.data());changed.config.governance.quorumVotes=1;await assert.rejects(Chain.fromData(changed),/configuration/);
  });
  await t.test('PoW does not authorize an overdrawn reserve payment',async()=>{
    const base=await Chain.fromData({config:structuredClone(chain.config),blocks:[structuredClone(chain.blocks[0])]});
    try{
      const changed=structuredClone(block);changed.header.reserveRelease=(BigInt(changed.header.reserveRelease)+1n).toString();
      changed.pow=base.engine().hash(changed.header,miningKey(base.emissionHistory,base.config.domain));changed.id=sha({header:changed.header,pow:changed.pow});
      await assert.rejects(base.append(changed),/reserve/);assert.equal(base.height,0);
    }finally{base.close();}
  });
  await t.test('double spend is rejected without partial block state',async()=>{
    const id=chain.blocks.at(-1).id,remaining=chain.reserveRemaining;await assert.rejects(chain.mine(miner,[transaction],{maxAttempts:10}),/Double spend/);
    assert.equal(chain.blocks.at(-1).id,id);assert.equal(chain.reserveRemaining,remaining);
  });
});
