import net from 'node:net';
export async function startSocks(routes) {
  const sockets=new Set(),requests=[];
  const proxy=net.createServer(client=>{
    sockets.add(client);client.on('close',()=>sockets.delete(client));client.on('error',()=>{});
    let stage=0,buffer=Buffer.alloc(0),credentials;
    const receive=chunk=>{
      buffer=Buffer.concat([buffer,chunk]);
      if(stage===0&&buffer.length>=3) {
        if(!buffer.subarray(0,3).equals(Buffer.from([5,1,2])))return client.destroy();
        buffer=buffer.subarray(3);stage=1;client.write(Buffer.from([5,2]));
      }
      if(stage===1&&buffer.length>=2) {
        const userLength=buffer[1];if(buffer.length<3+userLength)return;
        const passwordLength=buffer[2+userLength];if(buffer.length<3+userLength+passwordLength)return;
        credentials=buffer.subarray(2,2+userLength).toString();
        buffer=buffer.subarray(3+userLength+passwordLength);stage=2;client.write(Buffer.from([1,0]));
      }
      if(stage===2&&buffer.length>=5) {
        const size=buffer[4];if(buffer.length<7+size)return;
        const hostname=buffer.subarray(5,5+size).toString(),port=buffer.readUInt16BE(5+size);buffer=buffer.subarray(7+size);stage=3;
        requests.push({hostname,port,credentials});
        const target=routes[hostname];if(!target)return client.destroy();
        const upstream=net.connect({host:'127.0.0.1',port:target},()=>{
          client.write(Buffer.from([5,0,0,1,127,0,0,1,0,80]));
          client.off('data',receive);if(buffer.length)upstream.write(buffer);
          client.pipe(upstream);upstream.pipe(client);
        });
        sockets.add(upstream);upstream.on('close',()=>sockets.delete(upstream));
        upstream.on('error',()=>client.destroy());client.on('close',()=>upstream.destroy());
      }
    };client.on('data',receive);
  });
  await new Promise((resolve,reject)=>{proxy.once('error',reject);proxy.listen(0,'127.0.0.1',resolve);});
  return {port:proxy.address().port,requests,close:async()=>{for(const socket of sockets)socket.destroy();await new Promise(resolve=>proxy.close(resolve));}};
}
