import test from 'node:test';
import assert from 'node:assert/strict';
import net from 'node:net';
import { once } from 'node:events';
import { serveNode } from '../src/transport.mjs';

function fixture({archiveFailure=false}={}){
 const genesis={id:'a'.repeat(64),header:{configuration:'b'.repeat(64)}};
 const chain={config:{protocol:'ONLYPRIVACY-STARK-1'},blocks:[genesis],height:0,work:0n,data(){if(archiveFailure)throw Error('Private archive path must not escape');return {config:this.config,blocks:this.blocks};}};
 let validations=0;
 return {chain,halted:false,poolDurable:true,packets:()=>Array.from({length:32},(_,i)=>({index:i})),
 acceptTransaction:async()=>{validations++;throw Error('reject');},acceptBlock:async()=>{validations++;throw Error('reject');},get validations(){return validations;}};
}
async function withServer(node,fn){const server=serveNode(node,{port:0});await once(server,'listening');try{return await fn('http://127.0.0.1:'+server.address().port,server);}finally{server.closeAllConnections();await new Promise(resolve=>server.close(resolve));}}

test('public pending replies expose only a block-sized bounded batch',async()=>withServer(fixture(),async url=>{
 const response=await fetch(url+'/pending');assert.equal(response.status,200);
 assert.equal((await response.json()).packets.length,3);
}));
test('public archive read failures return a generic error without crashing',async()=>withServer(fixture({archiveFailure:true}),async url=>{
 const response=await fetch(url+'/chain',{signal:AbortSignal.timeout(3000)});assert.equal(response.status,503);
 const text=await response.text();assert.equal(text.includes('Private archive'),false);
 const tip=await fetch(url+'/tip');assert.equal(tip.status,200);assert.equal((await tip.json()).storageHalted,true);
}));
test('public requests reject browser origins, wrong content types, oversized and malformed bodies before validation',async()=>{
 const node=fixture();await withServer(node,async url=>{
  assert.equal((await fetch(url+'/tip',{headers:{Origin:'https://hostile.invalid'}})).status,403);
  assert.equal((await fetch(url+'/transaction',{method:'POST',body:'{}'})).status,415);
  assert.equal((await fetch(url+'/transaction',{method:'POST',headers:{'Content-Type':'application/json'},body:'{'})).status,400);
  assert.equal(node.validations,0);
  assert.equal((await fetch(url+'/range?from=-1&count=2')).status,404);
  assert.equal((await fetch(url+'/range?from=0&count=3')).status,404);
  const {hostname,port}=new URL(url);
  const status=await new Promise((resolve,reject)=>{const s=net.connect({host:hostname,port:Number(port)});s.once('connect',()=>s.write('POST /transaction HTTP/1.1\r\nHost: localhost\r\nContent-Type: application/json\r\nContent-Length: 7000000\r\nConnection: close\r\n\r\n'));s.once('data',data=>{resolve(data.toString().split('\r\n')[0]);s.destroy();});s.once('error',reject);s.setTimeout(3000,()=>{s.destroy();reject(Error('Missing admission rejection'));});});
  assert.match(status,/413/);assert.equal(node.validations,0);
 });
});
