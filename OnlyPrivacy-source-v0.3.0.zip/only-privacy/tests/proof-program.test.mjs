import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import {spawnSync} from 'node:child_process';
import path from 'node:path';
import {PROJECT} from '../src/proofs.mjs';
import {initialize,randomField,ownerOf,commitment,nullifier,bindingOf,fieldHash,digestWords,NoteTree,DEPTH} from '../src/primitives.mjs';
const layout=JSON.parse(await fs.readFile(path.join(PROJECT,'pq/witness-layout.json'),'utf8'));
await initialize();
function fixture({lock='10',height='10',value='100',out='90'}={}){
 const domain=randomField(),secret=randomField(),rho=randomField(),note={owner:ownerOf(secret,domain),rho,value,lock},tree=new NoteTree([commitment(note,domain)]),branch=tree.path(0);
 const outOwner=[ownerOf(randomField(),domain),ownerOf(randomField(),domain)],outRho=[randomField(),randomField()],extHash=fieldHash('private-program-test');
 const witness={inSecret:[secret,randomField()],inRho:[rho,randomField()],inValue:[value,'0'],inLock:[lock,'0'],siblings:[branch.siblings,Array(DEPTH).fill('0')],pathBits:[branch.pathBits,Array(DEPTH).fill(0)],outOwner,outRho,outValue:[out,'0'],outLock:['0','0']};
 const cm=[out,'0'].map((v,i)=>commitment({owner:outOwner[i],rho:outRho[i],value:v,lock:'0'},domain));
 const signals=[nullifier({secret,rho},domain),'0',...cm,bindingOf(outRho[0],extHash,tree.root,domain,height),domain,tree.root,'0','10',extHash,height,'0','0'];
 return {witness,signals};
}
function execute(f){
 const input={op:'execute',publicInput:f.signals.flatMap(s=>digestWords(s).map(String)),secretInput:layout.privateLayout.flatMap(({name,numeric})=>{const value=name.split('.').reduce((o,k)=>o[k],f.witness);return numeric?[String(value)]:digestWords(value).map(String);})};
 return spawnSync(path.join(PROJECT,'native/onlyprivacy-pq'),[],{input:JSON.stringify(input),encoding:'utf8',env:{RAYON_NUM_THREADS:'2'},timeout:10000});
}
test('fixed transfer program permits spending at exactly the unlock height',()=>assert.equal(execute(fixture()).status,0));
test('future-locked input fails even with its correct commitment and membership root',()=>assert.notEqual(execute(fixture({lock:'11'})).status,0));
test('unbalanced but individually committed outputs fail integer conservation',()=>assert.notEqual(execute(fixture({out:'91'})).status,0));
test('a prover bypassing JavaScript still cannot use a 64th amount bit',()=>assert.notEqual(execute(fixture({value:(1n<<63n).toString(),out:((1n<<63n)-10n).toString()})).status,0));
test('wrong ownership secret fails the fixed program',()=>{const f=fixture();f.witness.inSecret[0]=randomField();assert.notEqual(execute(f).status,0);});
test('non-boolean Merkle selector fails the fixed program',()=>{const f=fixture();f.witness.pathBits[0][0]=2;assert.notEqual(execute(f).status,0);});
test('wrong membership root fails the fixed program',()=>{const f=fixture();f.signals[6]=randomField();assert.notEqual(execute(f).status,0);});
