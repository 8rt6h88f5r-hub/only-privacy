import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { Chain } from '../src/chain.mjs';
import { PROJECT } from '../src/proofs.mjs';
import {readJSON,writeJSON} from '../src/storage.mjs';

test('block-directory storage replays proofs and rejects altered or missing archive files',{timeout:30000},async()=>{
 const dir=await fs.mkdtemp(path.join(os.tmpdir(),'onlyprivacy-archive-')),file=path.join(dir,'chain.json');
 const original=await Chain.load(path.join(PROJECT,'network/genesis.json'));let loaded;
 try{
  await original.save(file);const index=await readJSON(file);assert.equal(index.format,'onlyprivacy-block-directory-v1');assert.equal(index.blockIds[0],original.blocks[0].id);
  loaded=await Chain.load(file);assert.equal(loaded.supply,original.supply);loaded.close();loaded=null;
  const archived=path.join(file+'.blocks',index.blockIds[0]+'.json'),raw=await readJSON(archived);
  const changed=structuredClone(raw);changed.header.subsidy='1';await writeJSON(archived,changed);await assert.rejects(Chain.load(file));
  await fs.rm(archived);await assert.rejects(Chain.load(file),/ENOENT/);
 }finally{loaded?.close();original.close();await fs.rm(dir,{recursive:true,force:true});}
});
